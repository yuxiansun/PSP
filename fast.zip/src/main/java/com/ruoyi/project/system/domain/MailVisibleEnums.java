package com.ruoyi.project.system.domain;

public enum MailVisibleEnums {
    // 保存|未发送
    SAVE,
    // 已经发送
    SEND,
    // 发送失败
    FAIL

}
