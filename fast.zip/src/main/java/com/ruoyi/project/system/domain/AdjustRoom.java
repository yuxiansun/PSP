package com.ruoyi.project.system.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import com.ruoyi.framework.web.domain.BaseEntity;

/**
 * 【请填写功能名称】对象 adjust_room
 * 
 * @author ruoyi
 * @date 2023-05-02
 */
public class AdjustRoom extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** $column.columnComment */
    private Long id;

    /** 账号 */
    @Excel(name = "账号")
    private String username;

    /** 姓名 */
    @Excel(name = "姓名")
    private String name;

    /** 当前房间 */
    @Excel(name = "当前房间")
    private Long currentroomId;

    /** 当前床位号 */
    @Excel(name = "当前床位号")
    private Long currentbedId;

    /** 目标房间 */
    @Excel(name = "目标房间")
    private Long towardsroomId;

    /** 目标床位号 */
    @Excel(name = "目标床位号")
    private Long towardsbedId;

    /** 申请状态 */
    @Excel(name = "申请状态")
    private String state;

    /** 申请时间 */
    @Excel(name = "申请时间")
    private String applyTime;

    /** 处理时间 */
    @Excel(name = "处理时间")
    private String finishTime;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setUsername(String username) 
    {
        this.username = username;
    }

    public String getUsername() 
    {
        return username;
    }
    public void setName(String name) 
    {
        this.name = name;
    }

    public String getName() 
    {
        return name;
    }
    public void setCurrentroomId(Long currentroomId) 
    {
        this.currentroomId = currentroomId;
    }

    public Long getCurrentroomId() 
    {
        return currentroomId;
    }
    public void setCurrentbedId(Long currentbedId) 
    {
        this.currentbedId = currentbedId;
    }

    public Long getCurrentbedId() 
    {
        return currentbedId;
    }
    public void setTowardsroomId(Long towardsroomId) 
    {
        this.towardsroomId = towardsroomId;
    }

    public Long getTowardsroomId() 
    {
        return towardsroomId;
    }
    public void setTowardsbedId(Long towardsbedId) 
    {
        this.towardsbedId = towardsbedId;
    }

    public Long getTowardsbedId() 
    {
        return towardsbedId;
    }
    public void setState(String state) 
    {
        this.state = state;
    }

    public String getState() 
    {
        return state;
    }
    public void setApplyTime(String applyTime) 
    {
        this.applyTime = applyTime;
    }

    public String getApplyTime() 
    {
        return applyTime;
    }
    public void setFinishTime(String finishTime) 
    {
        this.finishTime = finishTime;
    }

    public String getFinishTime() 
    {
        return finishTime;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("username", getUsername())
            .append("name", getName())
            .append("currentroomId", getCurrentroomId())
            .append("currentbedId", getCurrentbedId())
            .append("towardsroomId", getTowardsroomId())
            .append("towardsbedId", getTowardsbedId())
            .append("state", getState())
            .append("applyTime", getApplyTime())
            .append("finishTime", getFinishTime())
            .toString();
    }
}
