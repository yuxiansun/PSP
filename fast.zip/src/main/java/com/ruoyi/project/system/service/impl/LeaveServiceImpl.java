package com.ruoyi.project.system.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.project.system.mapper.LeaveMapper;
import com.ruoyi.project.system.domain.Leave;
import com.ruoyi.project.system.service.ILeaveService;

/**
 * 【请填写功能名称】Service业务层处理
 * 
 * @author ruoyi
 * @date 2023-05-09
 */
@Service
public class LeaveServiceImpl implements ILeaveService 
{
    @Autowired
    private LeaveMapper leaveMapper;

    /**
     * 查询【请填写功能名称】
     * 
     * @param id 【请填写功能名称】主键
     * @return 【请填写功能名称】
     */
    @Override
    public Leave selectLeaveById(Long id)
    {
        return leaveMapper.selectLeaveById(id);
    }

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param leave 【请填写功能名称】
     * @return 【请填写功能名称】
     */
    @Override
    public List<Leave> selectLeaveList(Leave leave)
    {
        return leaveMapper.selectLeaveList(leave);
    }

    /**
     * 新增【请填写功能名称】
     * 
     * @param leave 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int insertLeave(Leave leave)
    {
        return leaveMapper.insertLeave(leave);
    }

    /**
     * 修改【请填写功能名称】
     * 
     * @param leave 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int updateLeave(Leave leave)
    {
        return leaveMapper.updateLeave(leave);
    }

    /**
     * 批量删除【请填写功能名称】
     * 
     * @param ids 需要删除的【请填写功能名称】主键
     * @return 结果
     */
    @Override
    public int deleteLeaveByIds(Long[] ids)
    {
        return leaveMapper.deleteLeaveByIds(ids);
    }

    /**
     * 删除【请填写功能名称】信息
     * 
     * @param id 【请填写功能名称】主键
     * @return 结果
     */
    @Override
    public int deleteLeaveById(Long id)
    {
        return leaveMapper.deleteLeaveById(id);
    }
}
