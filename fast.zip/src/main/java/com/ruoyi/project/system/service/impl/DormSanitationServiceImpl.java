package com.ruoyi.project.system.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.project.system.mapper.DormSanitationMapper;
import com.ruoyi.project.system.domain.DormSanitation;
import com.ruoyi.project.system.service.IDormSanitationService;

/**
 * 【请填写功能名称】Service业务层处理
 * 
 * @author ruoyi
 * @date 2023-05-03
 */
@Service
public class DormSanitationServiceImpl implements IDormSanitationService 
{
    @Autowired
    private DormSanitationMapper dormSanitationMapper;

    /**
     * 查询【请填写功能名称】
     * 
     * @param id 【请填写功能名称】主键
     * @return 【请填写功能名称】
     */
    @Override
    public DormSanitation selectDormSanitationById(Long id)
    {
        return dormSanitationMapper.selectDormSanitationById(id);
    }

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param dormSanitation 【请填写功能名称】
     * @return 【请填写功能名称】
     */
    @Override
    public List<DormSanitation> selectDormSanitationList(DormSanitation dormSanitation)
    {
        return dormSanitationMapper.selectDormSanitationList(dormSanitation);
    }

    /**
     * 新增【请填写功能名称】
     * 
     * @param dormSanitation 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int insertDormSanitation(DormSanitation dormSanitation)
    {
        if (dormSanitation.getScoreTotal() == null) {
            dormSanitation.setScoreTotal(100);
        }
        DormSanitation dormSanitation1;
        if (dormSanitation.getQualified().equals("1")) {
            dormSanitation1 = dormSanitationMapper.selectDormSanitationByDorm(dormSanitation);
            if (dormSanitation1 != null && dormSanitation1.getDeductedScore() != null) {
                dormSanitation.setScoreTotal(dormSanitation.getScoreTotal() - (dormSanitation1.getDeductedScore() + dormSanitation.getDeductedScore()));
                dormSanitationMapper.updateDormSanitation(dormSanitation);
            } else {
                dormSanitation.setScoreTotal(dormSanitation.getScoreTotal() - dormSanitation.getDeductedScore());
            }
        }
        dormSanitationMapper.updateDormSanitationByDorm(dormSanitation);
        return dormSanitationMapper.insertDormSanitation(dormSanitation);
    }

    /**
     * 修改【请填写功能名称】
     * 
     * @param dormSanitation 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int updateDormSanitation(DormSanitation dormSanitation)
    {
        if (dormSanitation.getScoreTotal() == null) {
            dormSanitation.setScoreTotal(100);
        }
        DormSanitation dormSanitation1;
        if (dormSanitation.getQualified().equals("1")) {
            dormSanitation1 = dormSanitationMapper.selectDormSanitationByDorm(dormSanitation);
            DormSanitation dormSanitation2 = dormSanitationMapper.selectDormSanitationById(dormSanitation.getId());
            if (dormSanitation1 != null && dormSanitation1.getDeductedScore() != null) {
                dormSanitation.setScoreTotal(100 - dormSanitation1.getDeductedScore() + dormSanitation2.getDeductedScore() - dormSanitation.getDeductedScore());
                dormSanitationMapper.updateDormSanitation(dormSanitation);
            } else {
                dormSanitation.setScoreTotal(100 - dormSanitation.getDeductedScore());
            }
        }
        dormSanitationMapper.updateDormSanitationByDorm(dormSanitation);
        return dormSanitationMapper.updateDormSanitation(dormSanitation);
    }

    /**
     * 批量删除【请填写功能名称】
     * 
     * @param ids 需要删除的【请填写功能名称】主键
     * @return 结果
     */
    @Override
    public int deleteDormSanitationByIds(Long[] ids)
    {
        return dormSanitationMapper.deleteDormSanitationByIds(ids);
    }

    /**
     * 删除【请填写功能名称】信息
     * 
     * @param id 【请填写功能名称】主键
     * @return 结果
     */
    @Override
    public int deleteDormSanitationById(Long id)
    {
        return dormSanitationMapper.deleteDormSanitationById(id);
    }

    @Override
    public DormSanitation selectDormSanitationByDorm(DormSanitation dormSanitation) {
        return dormSanitationMapper.selectDormSanitationByDorm(dormSanitation);
    }

    @Override
    public int updateDormSanitationByDorm(DormSanitation dormSanitation) {
        return dormSanitationMapper.updateDormSanitationByDorm(dormSanitation);
    }
}
