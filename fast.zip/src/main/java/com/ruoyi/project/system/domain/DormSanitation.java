package com.ruoyi.project.system.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import com.ruoyi.framework.web.domain.BaseEntity;

/**
 * 【请填写功能名称】对象 dorm_sanitation
 * 
 * @author ruoyi
 * @date 2023-05-03
 */
public class DormSanitation extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** $column.columnComment */
    private Long id;

    /** 宿舍楼 */
    @Excel(name = "宿舍楼")
    private Long dormbuildId;

    /** 宿舍楼名称 */
    @Excel(name = "宿舍楼名称")
    private String dormbuildName;

    /** 宿舍id */
    @Excel(name = "宿舍id")
    private Long dormroomId;

    /** 总分 */
    @Excel(name = "总分")
    private Integer scoreTotal;

    /** 扣分 */
    @Excel(name = "扣分")
    private Integer deductedScore;

    /** 扣分床位 */
    @Excel(name = "扣分床位")
    private String deductedBed;

    /** 扣分原因 */
    @Excel(name = "扣分原因")
    private String deductedReason;

    /** 检查时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "检查时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date examineTime;

    /** 是否合格 1 合格 2 不合格 */
    @Excel(name = "是否合格 1 合格 2 不合格")
    private String qualified;

    /** 是否删除 2 删除 */
    private String delFlag;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setDormbuildId(Long dormbuildId) 
    {
        this.dormbuildId = dormbuildId;
    }

    public Long getDormbuildId() 
    {
        return dormbuildId;
    }
    public void setDormbuildName(String dormbuildName) 
    {
        this.dormbuildName = dormbuildName;
    }

    public String getDormbuildName() 
    {
        return dormbuildName;
    }
    public void setDormroomId(Long dormroomId) 
    {
        this.dormroomId = dormroomId;
    }

    public Long getDormroomId() 
    {
        return dormroomId;
    }
    public void setScoreTotal(Integer scoreTotal) 
    {
        this.scoreTotal = scoreTotal;
    }

    public Integer getScoreTotal() 
    {
        return scoreTotal;
    }
    public void setDeductedScore(Integer deductedScore) 
    {
        this.deductedScore = deductedScore;
    }

    public Integer getDeductedScore() 
    {
        return deductedScore;
    }
    public void setDeductedBed(String deductedBed) 
    {
        this.deductedBed = deductedBed;
    }

    public String getDeductedBed() 
    {
        return deductedBed;
    }
    public void setDeductedReason(String deductedReason) 
    {
        this.deductedReason = deductedReason;
    }

    public String getDeductedReason() 
    {
        return deductedReason;
    }
    public void setExamineTime(Date examineTime) 
    {
        this.examineTime = examineTime;
    }

    public Date getExamineTime() 
    {
        return examineTime;
    }
    public void setQualified(String qualified) 
    {
        this.qualified = qualified;
    }

    public String getQualified() 
    {
        return qualified;
    }
    public void setDelFlag(String delFlag) 
    {
        this.delFlag = delFlag;
    }

    public String getDelFlag() 
    {
        return delFlag;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("dormbuildId", getDormbuildId())
            .append("dormbuildName", getDormbuildName())
            .append("dormroomId", getDormroomId())
            .append("scoreTotal", getScoreTotal())
            .append("deductedScore", getDeductedScore())
            .append("deductedBed", getDeductedBed())
            .append("deductedReason", getDeductedReason())
            .append("examineTime", getExamineTime())
            .append("qualified", getQualified())
            .append("delFlag", getDelFlag())
            .toString();
    }
}
