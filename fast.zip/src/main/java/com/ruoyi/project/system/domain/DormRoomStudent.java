package com.ruoyi.project.system.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import com.ruoyi.framework.web.domain.BaseEntity;

/**
 * 【请填写功能名称】对象 dorm_room_student
 * 
 * @author ruoyi
 * @date 2023-05-03
 */
public class DormRoomStudent extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 宿舍号 */
    @Excel(name = "宿舍号")
    private Long dormroomId;

    /** 学号 */
    @Excel(name = "学号")
    private String studentNumber;

    @Excel(name = "床位号")
    private Integer bedNumber;

    /** 宿舍楼号码 */
    @Excel(name = "宿舍楼号码")
    private Long dormbuildId;

    /** $column.columnComment */
    private Long id;

    private String dormbuildName;

    public void setDormroomId(Long dormroomId) 
    {
        this.dormroomId = dormroomId;
    }

    public Long getDormroomId() 
    {
        return dormroomId;
    }
    public void setStudentNumber(String studentNumber) 
    {
        this.studentNumber = studentNumber;
    }

    public String getStudentNumber() 
    {
        return studentNumber;
    }
    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }

    public Integer getBedNumber() {
        return bedNumber;
    }

    public void setBedNumber(Integer bedNumber) {
        this.bedNumber = bedNumber;
    }

    public Long getDormbuildId() {
        return dormbuildId;
    }

    public void setDormbuildId(Long dormbuildId) {
        this.dormbuildId = dormbuildId;
    }

    public String getDormbuildName() {
        return dormbuildName;
    }

    public void setDormbuildName(String dormbuildName) {
        this.dormbuildName = dormbuildName;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("dormroomId", getDormroomId())
            .append("studentNumber", getStudentNumber())
            .append("bedNumber", getBedNumber())
            .append("dormbuildId", getDormbuildId())
            .append("id", getId())
            .append("dormbuildName", getDormbuildName())
            .toString();
    }
}
