package com.ruoyi.project.system.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.project.system.mapper.VisitorMapper;
import com.ruoyi.project.system.domain.Visitor;
import com.ruoyi.project.system.service.IVisitorService;

/**
 * 【请填写功能名称】Service业务层处理
 * 
 * @author ruoyi
 * @date 2023-05-02
 */
@Service
public class VisitorServiceImpl implements IVisitorService 
{
    @Autowired
    private VisitorMapper visitorMapper;

    /**
     * 查询【请填写功能名称】
     * 
     * @param id 【请填写功能名称】主键
     * @return 【请填写功能名称】
     */
    @Override
    public Visitor selectVisitorById(Long id)
    {
        return visitorMapper.selectVisitorById(id);
    }

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param visitor 【请填写功能名称】
     * @return 【请填写功能名称】
     */
    @Override
    public List<Visitor> selectVisitorList(Visitor visitor)
    {
        return visitorMapper.selectVisitorList(visitor);
    }

    /**
     * 新增【请填写功能名称】
     * 
     * @param visitor 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int insertVisitor(Visitor visitor)
    {
        return visitorMapper.insertVisitor(visitor);
    }

    /**
     * 修改【请填写功能名称】
     * 
     * @param visitor 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int updateVisitor(Visitor visitor)
    {
        return visitorMapper.updateVisitor(visitor);
    }

    /**
     * 批量删除【请填写功能名称】
     * 
     * @param ids 需要删除的【请填写功能名称】主键
     * @return 结果
     */
    @Override
    public int deleteVisitorByIds(Long[] ids)
    {
        return visitorMapper.deleteVisitorByIds(ids);
    }

    /**
     * 删除【请填写功能名称】信息
     * 
     * @param id 【请填写功能名称】主键
     * @return 结果
     */
    @Override
    public int deleteVisitorById(Long id)
    {
        return visitorMapper.deleteVisitorById(id);
    }
}
