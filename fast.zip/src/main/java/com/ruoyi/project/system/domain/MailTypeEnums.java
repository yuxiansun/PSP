package com.ruoyi.project.system.domain;

public enum MailTypeEnums {
    /* 文本 */
    TEXT_MAIL,
    /* 纯HTML */
    HTML_MAIL,
    /* 模板 */
    TEMPLATE_MAIL;
}
