package com.ruoyi.project.system.service.impl;

import java.util.List;

import com.ruoyi.common.utils.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.project.system.mapper.RepairMapper;
import com.ruoyi.project.system.domain.Repair;
import com.ruoyi.project.system.service.IRepairService;

/**
 * 【请填写功能名称】Service业务层处理
 * 
 * @author ruoyi
 * @date 2023-05-02
 */
@Service
public class RepairServiceImpl implements IRepairService 
{
    @Autowired
    private RepairMapper repairMapper;

    /**
     * 查询【请填写功能名称】
     * 
     * @param id 【请填写功能名称】主键
     * @return 【请填写功能名称】
     */
    @Override
    public Repair selectRepairById(Long id)
    {
        return repairMapper.selectRepairById(id);
    }

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param repair 【请填写功能名称】
     * @return 【请填写功能名称】
     */
    @Override
    public List<Repair> selectRepairList(Repair repair)
    {
        return repairMapper.selectRepairList(repair);
    }

    /**
     * 新增【请填写功能名称】
     * 
     * @param repair 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int insertRepair(Repair repair)
    {
        repair.setState("0");
        return repairMapper.insertRepair(repair);
    }

    /**
     * 修改【请填写功能名称】
     * 
     * @param repair 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int updateRepair(Repair repair)
    {
        return repairMapper.updateRepair(repair);
    }

    /**
     * 批量删除【请填写功能名称】
     * 
     * @param ids 需要删除的【请填写功能名称】主键
     * @return 结果
     */
    @Override
    public int deleteRepairByIds(Long[] ids)
    {
        return repairMapper.deleteRepairByIds(ids);
    }

    /**
     * 删除【请填写功能名称】信息
     * 
     * @param id 【请填写功能名称】主键
     * @return 结果
     */
    @Override
    public int deleteRepairById(Long id)
    {
        return repairMapper.deleteRepairById(id);
    }

    @Override
    public int updateRepairStatus(Repair repair) {
        return repairMapper.updateRepairStatus(repair);
    }
}
