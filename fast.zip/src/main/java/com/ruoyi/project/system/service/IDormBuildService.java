package com.ruoyi.project.system.service;

import java.util.List;
import com.ruoyi.project.system.domain.DormBuild;
import com.ruoyi.project.system.domain.SysUser;

/**
 * 【请填写功能名称】Service接口
 * 
 * @author ruoyi
 * @date 2023-05-02
 */
public interface IDormBuildService 
{
    /**
     * 查询【请填写功能名称】
     * 
     * @param id 【请填写功能名称】主键
     * @return 【请填写功能名称】
     */
    public DormBuild selectDormBuildById(Long id);

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param dormBuild 【请填写功能名称】
     * @return 【请填写功能名称】集合
     */
    public List<DormBuild> selectDormBuildList(DormBuild dormBuild);

    /**
     * 新增【请填写功能名称】
     * 
     * @param dormBuild 【请填写功能名称】
     * @return 结果
     */
    public int insertDormBuild(DormBuild dormBuild);

    /**
     * 修改【请填写功能名称】
     * 
     * @param dormBuild 【请填写功能名称】
     * @return 结果
     */
    public int updateDormBuild(DormBuild dormBuild);

    /**
     * 批量删除【请填写功能名称】
     * 
     * @param ids 需要删除的【请填写功能名称】主键集合
     * @return 结果
     */
    public int deleteDormBuildByIds(Long[] ids);

    /**
     * 删除【请填写功能名称】信息
     * 
     * @param id 【请填写功能名称】主键
     * @return 结果
     */
    public int deleteDormBuildById(Long id);

    /**
     * 校验楼栋信息是否唯一
     * @param dormBuild
     * @return
     */
    public boolean checkBuildNumberUnique(DormBuild dormBuild);
}
