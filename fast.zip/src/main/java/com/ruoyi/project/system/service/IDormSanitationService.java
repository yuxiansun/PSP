package com.ruoyi.project.system.service;

import java.util.List;
import com.ruoyi.project.system.domain.DormSanitation;

/**
 * 【请填写功能名称】Service接口
 * 
 * @author ruoyi
 * @date 2023-05-03
 */
public interface IDormSanitationService 
{
    /**
     * 查询【请填写功能名称】
     * 
     * @param id 【请填写功能名称】主键
     * @return 【请填写功能名称】
     */
    public DormSanitation selectDormSanitationById(Long id);

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param dormSanitation 【请填写功能名称】
     * @return 【请填写功能名称】集合
     */
    public List<DormSanitation> selectDormSanitationList(DormSanitation dormSanitation);

    /**
     * 新增【请填写功能名称】
     * 
     * @param dormSanitation 【请填写功能名称】
     * @return 结果
     */
    public int insertDormSanitation(DormSanitation dormSanitation);

    /**
     * 修改【请填写功能名称】
     * 
     * @param dormSanitation 【请填写功能名称】
     * @return 结果
     */
    public int updateDormSanitation(DormSanitation dormSanitation);

    /**
     * 批量删除【请填写功能名称】
     * 
     * @param ids 需要删除的【请填写功能名称】主键集合
     * @return 结果
     */
    public int deleteDormSanitationByIds(Long[] ids);

    /**
     * 删除【请填写功能名称】信息
     * 
     * @param id 【请填写功能名称】主键
     * @return 结果
     */
    public int deleteDormSanitationById(Long id);

    /**
     * 根据宿舍信息查询
     * @param dormSanitation
     * @return
     */
    public DormSanitation selectDormSanitationByDorm(DormSanitation dormSanitation);

    public int updateDormSanitationByDorm(DormSanitation dormSanitation);
}
