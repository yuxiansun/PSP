package com.ruoyi.project.system.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.project.system.mapper.AdjustRoomMapper;
import com.ruoyi.project.system.domain.AdjustRoom;
import com.ruoyi.project.system.service.IAdjustRoomService;

/**
 * 【请填写功能名称】Service业务层处理
 * 
 * @author ruoyi
 * @date 2023-05-02
 */
@Service
public class AdjustRoomServiceImpl implements IAdjustRoomService 
{
    @Autowired
    private AdjustRoomMapper adjustRoomMapper;

    /**
     * 查询【请填写功能名称】
     * 
     * @param id 【请填写功能名称】主键
     * @return 【请填写功能名称】
     */
    @Override
    public AdjustRoom selectAdjustRoomById(Long id)
    {
        return adjustRoomMapper.selectAdjustRoomById(id);
    }

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param adjustRoom 【请填写功能名称】
     * @return 【请填写功能名称】
     */
    @Override
    public List<AdjustRoom> selectAdjustRoomList(AdjustRoom adjustRoom)
    {
        return adjustRoomMapper.selectAdjustRoomList(adjustRoom);
    }

    /**
     * 新增【请填写功能名称】
     * 
     * @param adjustRoom 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int insertAdjustRoom(AdjustRoom adjustRoom)
    {
        return adjustRoomMapper.insertAdjustRoom(adjustRoom);
    }

    /**
     * 修改【请填写功能名称】
     * 
     * @param adjustRoom 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int updateAdjustRoom(AdjustRoom adjustRoom)
    {
        return adjustRoomMapper.updateAdjustRoom(adjustRoom);
    }

    /**
     * 批量删除【请填写功能名称】
     * 
     * @param ids 需要删除的【请填写功能名称】主键
     * @return 结果
     */
    @Override
    public int deleteAdjustRoomByIds(Long[] ids)
    {
        return adjustRoomMapper.deleteAdjustRoomByIds(ids);
    }

    /**
     * 删除【请填写功能名称】信息
     * 
     * @param id 【请填写功能名称】主键
     * @return 结果
     */
    @Override
    public int deleteAdjustRoomById(Long id)
    {
        return adjustRoomMapper.deleteAdjustRoomById(id);
    }
}
