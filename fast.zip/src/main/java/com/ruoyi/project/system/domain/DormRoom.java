package com.ruoyi.project.system.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import com.ruoyi.framework.web.domain.BaseEntity;

/**
 * 【请填写功能名称】对象 dorm_room
 * 
 * @author ruoyi
 * @date 2023-05-02
 */
public class DormRoom extends BaseEntity
{
    private static final long serialVersionUID = 1L;


    /** 宿舍房间号 */
    private Integer id;

    /** 宿舍房间号 */
    private Long dormroomId;

    /** 宿舍楼号 */
    @Excel(name = "宿舍楼号")
    private Long dormbuildId;

    /** 楼层 */
    @Excel(name = "楼层")
    private Long floorNum;

    /** 房间最大入住人数 */
    @Excel(name = "房间最大入住人数")
    private Long maxCapacity;

    /** 当前房间入住人数 */
    @Excel(name = "当前房间入住人数")
    private Long currentCapacity;

    /** 一号床位 */
    @Excel(name = "一号床位")
    private String firstBed;

    /** 二号床位 */
    @Excel(name = "二号床位")
    private String secondBed;

    /** 三号床位 */
    @Excel(name = "三号床位")
    private String thirdBed;

    /** 四号床位 */
    @Excel(name = "四号床位")
    private String fourthBed;

    /** 五号床位 */
    @Excel(name = "五号床位")
    private String fivethBed;

    /** 六号床位 */
    @Excel(name = "六号床位")
    private String sixthBed;

    /** 七号床位 */
    @Excel(name = "七号床位")
    private String seventhBed;

    /** 八号床位 */
    @Excel(name = "八号床位")
    private String eightBed;

    public void setDormroomId(Long dormroomId) 
    {
        this.dormroomId = dormroomId;
    }

    public Long getDormroomId() 
    {
        return dormroomId;
    }
    public void setDormbuildId(Long dormbuildId) 
    {
        this.dormbuildId = dormbuildId;
    }

    public Long getDormbuildId() 
    {
        return dormbuildId;
    }
    public void setFloorNum(Long floorNum) 
    {
        this.floorNum = floorNum;
    }

    public Long getFloorNum() 
    {
        return floorNum;
    }
    public void setMaxCapacity(Long maxCapacity) 
    {
        this.maxCapacity = maxCapacity;
    }

    public Long getMaxCapacity() 
    {
        return maxCapacity;
    }
    public void setCurrentCapacity(Long currentCapacity) 
    {
        this.currentCapacity = currentCapacity;
    }

    public Long getCurrentCapacity() 
    {
        return currentCapacity;
    }
    public void setFirstBed(String firstBed) 
    {
        this.firstBed = firstBed;
    }

    public String getFirstBed() 
    {
        return firstBed;
    }
    public void setSecondBed(String secondBed) 
    {
        this.secondBed = secondBed;
    }

    public String getSecondBed() 
    {
        return secondBed;
    }
    public void setThirdBed(String thirdBed) 
    {
        this.thirdBed = thirdBed;
    }

    public String getThirdBed() 
    {
        return thirdBed;
    }
    public void setFourthBed(String fourthBed) 
    {
        this.fourthBed = fourthBed;
    }

    public String getFourthBed() 
    {
        return fourthBed;
    }
    public void setFivethBed(String fivethBed) 
    {
        this.fivethBed = fivethBed;
    }

    public String getFivethBed() 
    {
        return fivethBed;
    }
    public void setSixthBed(String sixthBed) 
    {
        this.sixthBed = sixthBed;
    }

    public String getSixthBed() 
    {
        return sixthBed;
    }
    public void setSeventhBed(String seventhBed) 
    {
        this.seventhBed = seventhBed;
    }

    public String getSeventhBed() 
    {
        return seventhBed;
    }
    public void setEightBed(String eightBed) 
    {
        this.eightBed = eightBed;
    }

    public String getEightBed() 
    {
        return eightBed;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("dormroomId", getDormroomId())
            .append("dormbuildId", getDormbuildId())
            .append("floorNum", getFloorNum())
            .append("maxCapacity", getMaxCapacity())
            .append("currentCapacity", getCurrentCapacity())
            .append("firstBed", getFirstBed())
            .append("secondBed", getSecondBed())
            .append("thirdBed", getThirdBed())
            .append("fourthBed", getFourthBed())
            .append("fivethBed", getFivethBed())
            .append("sixthBed", getSixthBed())
            .append("seventhBed", getSeventhBed())
            .append("eightBed", getEightBed())
            .toString();
    }
}
