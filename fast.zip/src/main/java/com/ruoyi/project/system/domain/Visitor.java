package com.ruoyi.project.system.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import com.ruoyi.framework.web.domain.BaseEntity;

/**
 * 【请填写功能名称】对象 visitor
 * 
 * @author ruoyi
 * @date 2023-05-02
 */
public class Visitor extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** $column.columnComment */
    private Long id;

    /** 姓名 */
    @Excel(name = "姓名")
    private String name;

    /** 性别 */
    @Excel(name = "性别")
    private String gender;

    /** 电话 */
    @Excel(name = "电话")
    private String phoneNum;

    /** 来源城市 */
    @Excel(name = "来源城市")
    private String originCity;

    /** 来访时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "来访时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date visitTime;

    /** 事情 */
    @Excel(name = "事情")
    private String content;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setName(String name) 
    {
        this.name = name;
    }

    public String getName() 
    {
        return name;
    }
    public void setGender(String gender) 
    {
        this.gender = gender;
    }

    public String getGender() 
    {
        return gender;
    }
    public void setPhoneNum(String phoneNum) 
    {
        this.phoneNum = phoneNum;
    }

    public String getPhoneNum() 
    {
        return phoneNum;
    }
    public void setOriginCity(String originCity) 
    {
        this.originCity = originCity;
    }

    public String getOriginCity() 
    {
        return originCity;
    }
    public void setVisitTime(Date visitTime) 
    {
        this.visitTime = visitTime;
    }

    public Date getVisitTime() 
    {
        return visitTime;
    }
    public void setContent(String content) 
    {
        this.content = content;
    }

    public String getContent() 
    {
        return content;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("name", getName())
            .append("gender", getGender())
            .append("phoneNum", getPhoneNum())
            .append("originCity", getOriginCity())
            .append("visitTime", getVisitTime())
            .append("content", getContent())
            .toString();
    }
}
