package com.ruoyi.project.system.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.project.system.mapper.DormRoomStudentMapper;
import com.ruoyi.project.system.domain.DormRoomStudent;
import com.ruoyi.project.system.service.IDormRoomStudentService;

/**
 * 【请填写功能名称】Service业务层处理
 * 
 * @author ruoyi
 * @date 2023-05-03
 */
@Service
public class DormRoomStudentServiceImpl implements IDormRoomStudentService 
{
    @Autowired
    private DormRoomStudentMapper dormRoomStudentMapper;

    /**
     * 查询【请填写功能名称】
     * 
     * @param id 【请填写功能名称】主键
     * @return 【请填写功能名称】
     */
    @Override
    public DormRoomStudent selectDormRoomStudentById(Long id)
    {
        return dormRoomStudentMapper.selectDormRoomStudentById(id);
    }

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param dormRoomStudent 【请填写功能名称】
     * @return 【请填写功能名称】
     */
    @Override
    public List<DormRoomStudent> selectDormRoomStudentList(DormRoomStudent dormRoomStudent)
    {
        return dormRoomStudentMapper.selectDormRoomStudentList(dormRoomStudent);
    }

    /**
     * 新增【请填写功能名称】
     * 
     * @param dormRoomStudent 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int insertDormRoomStudent(DormRoomStudent dormRoomStudent)
    {
        return dormRoomStudentMapper.insertDormRoomStudent(dormRoomStudent);
    }

    /**
     * 修改【请填写功能名称】
     * 
     * @param dormRoomStudent 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int updateDormRoomStudent(DormRoomStudent dormRoomStudent)
    {
        return dormRoomStudentMapper.updateDormRoomStudent(dormRoomStudent);
    }

    /**
     * 批量删除【请填写功能名称】
     * 
     * @param ids 需要删除的【请填写功能名称】主键
     * @return 结果
     */
    @Override
    public int deleteDormRoomStudentByIds(Long[] ids)
    {
        return dormRoomStudentMapper.deleteDormRoomStudentByIds(ids);
    }

    /**
     * 删除【请填写功能名称】信息
     * 
     * @param id 【请填写功能名称】主键
     * @return 结果
     */
    @Override
    public int deleteDormRoomStudentById(Long id)
    {
        return dormRoomStudentMapper.deleteDormRoomStudentById(id);
    }

    @Override
    public DormRoomStudent selectDormRoomStudentByStudentNumber(String studentNumber) {
        return dormRoomStudentMapper.selectDormRoomStudentByStudentNumber(studentNumber);
    }
}
