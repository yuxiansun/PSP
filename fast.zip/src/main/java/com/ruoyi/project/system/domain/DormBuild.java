package com.ruoyi.project.system.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import com.ruoyi.framework.web.domain.BaseEntity;

/**
 * 【请填写功能名称】对象 dorm_build
 * 
 * @author ruoyi
 * @date 2023-05-02
 */
public class DormBuild extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 宿舍楼号码 */
    @Excel(name = "宿舍楼号码")
    private Long dormbuildId;

    /** 宿舍楼名称 */
    @Excel(name = "宿舍楼名称")
    private String dormbuildName;

    /** 宿舍楼备注 */
    @Excel(name = "宿舍楼备注")
    private String dormbuildDetail;

    /** 主键 */
    private Long id;

    /** 宿舍楼备注 */
    @Excel(name = "宿舍楼备注")
    private char delFlag;

    @Excel(name = "宿舍分类")
    private String dormbuildSex;

    public void setDormbuildId(Long dormbuildId)
    {
        this.dormbuildId = dormbuildId;
    }

    public Long getDormbuildId()
    {
        return dormbuildId;
    }
    public void setDormbuildName(String dormbuildName) 
    {
        this.dormbuildName = dormbuildName;
    }

    public String getDormbuildName() 
    {
        return dormbuildName;
    }
    public void setDormbuildDetail(String dormbuildDetail) 
    {
        this.dormbuildDetail = dormbuildDetail;
    }

    public String getDormbuildDetail() 
    {
        return dormbuildDetail;
    }
    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }

    public char getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(char delFlag) {
        this.delFlag = delFlag;
    }

    public String getDormbuildSex() {
        return dormbuildSex;
    }

    public void setDormbuildSex(String dormbuildSex) {
        this.dormbuildSex = dormbuildSex;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("dormbuildId", getDormbuildId())
            .append("dormbuildName", getDormbuildName())
            .append("dormbuildDetail", getDormbuildDetail())
            .append("id", getId())
            .append("delFLag", getId())
            .append("dormbuildSex", getDormbuildSex())
                .toString();
    }
}
