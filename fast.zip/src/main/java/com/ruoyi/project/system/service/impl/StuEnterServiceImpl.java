package com.ruoyi.project.system.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.project.system.mapper.StuEnterMapper;
import com.ruoyi.project.system.domain.StuEnter;
import com.ruoyi.project.system.service.IStuEnterService;

/**
 * 【请填写功能名称】Service业务层处理
 * 
 * @author ruoyi
 * @date 2023-05-11
 */
@Service
public class StuEnterServiceImpl implements IStuEnterService 
{
    @Autowired
    private StuEnterMapper stuEnterMapper;

    /**
     * 查询【请填写功能名称】
     * 
     * @param id 【请填写功能名称】主键
     * @return 【请填写功能名称】
     */
    @Override
    public StuEnter selectStuEnterById(Long id)
    {
        return stuEnterMapper.selectStuEnterById(id);
    }

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param stuEnter 【请填写功能名称】
     * @return 【请填写功能名称】
     */
    @Override
    public List<StuEnter> selectStuEnterList(StuEnter stuEnter)
    {
        return stuEnterMapper.selectStuEnterList(stuEnter);
    }

    /**
     * 新增【请填写功能名称】
     * 
     * @param stuEnter 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int insertStuEnter(StuEnter stuEnter)
    {
        return stuEnterMapper.insertStuEnter(stuEnter);
    }

    /**
     * 修改【请填写功能名称】
     * 
     * @param stuEnter 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int updateStuEnter(StuEnter stuEnter)
    {
        return stuEnterMapper.updateStuEnter(stuEnter);
    }

    /**
     * 批量删除【请填写功能名称】
     * 
     * @param ids 需要删除的【请填写功能名称】主键
     * @return 结果
     */
    @Override
    public int deleteStuEnterByIds(Long[] ids)
    {
        return stuEnterMapper.deleteStuEnterByIds(ids);
    }

    /**
     * 删除【请填写功能名称】信息
     * 
     * @param id 【请填写功能名称】主键
     * @return 结果
     */
    @Override
    public int deleteStuEnterById(Long id)
    {
        return stuEnterMapper.deleteStuEnterById(id);
    }
}
