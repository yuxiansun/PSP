package com.ruoyi.project.system.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import com.ruoyi.framework.web.domain.BaseEntity;

/**
 * 【请填写功能名称】对象 repair
 * 
 * @author ruoyi
 * @date 2023-05-02
 */
public class Repair extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 订单编号 */
    private Long id;

    /** 报修人 */
    @Excel(name = "报修人")
    private String repairer;

    @Excel(name = "报修人学号")
    private String repairerId;

    /** 报修宿舍楼 */
    @Excel(name = "报修宿舍楼")
    private Long dormbuildId;

    /** 报修宿舍房间号 */
    @Excel(name = "报修宿舍房间号")
    private Long dormroomId;

    /** 表单标题 */
    @Excel(name = "表单标题")
    private String title;

    /** 表单内容 */
    @Excel(name = "表单内容")
    private String content;

    /** 订单状态（是否维修完成） */
    @Excel(name = "订单状态", readConverterExp = "是=否维修完成")
    private String state;

    /** 订单创建时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "订单创建时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date orderBuildtime;

    /** 订单完成时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date orderFinishtime;

    @Excel(name = "楼栋名称")
    private String dormbuildName;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setRepairer(String repairer) 
    {
        this.repairer = repairer;
    }

    public String getRepairer() 
    {
        return repairer;
    }
    public void setDormbuildId(Long dormbuildId) 
    {
        this.dormbuildId = dormbuildId;
    }

    public Long getDormbuildId() 
    {
        return dormbuildId;
    }
    public void setDormroomId(Long dormroomId) 
    {
        this.dormroomId = dormroomId;
    }

    public Long getDormroomId() 
    {
        return dormroomId;
    }
    public void setTitle(String title) 
    {
        this.title = title;
    }

    public String getTitle() 
    {
        return title;
    }
    public void setContent(String content) 
    {
        this.content = content;
    }

    public String getContent() 
    {
        return content;
    }
    public void setState(String state) 
    {
        this.state = state;
    }

    public String getState() 
    {
        return state;
    }
    public void setOrderBuildtime(Date orderBuildtime) 
    {
        this.orderBuildtime = orderBuildtime;
    }

    public Date getOrderBuildtime() 
    {
        return orderBuildtime;
    }
    public void setOrderFinishtime(Date orderFinishtime) 
    {
        this.orderFinishtime = orderFinishtime;
    }

    public Date getOrderFinishtime() 
    {
        return orderFinishtime;
    }

    public String getRepairerId() {
        return repairerId;
    }

    public void setRepairerId(String repairerId) {
        this.repairerId = repairerId;
    }

    public String getDormbuildName() {
        return dormbuildName;
    }

    public void setDormbuildName(String dormbuildName) {
        this.dormbuildName = dormbuildName;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("repairer", getRepairer())
            .append("repairerId", getRepairerId())
            .append("dormbuildId", getDormbuildId())
            .append("dormroomId", getDormroomId())
            .append("dormbuildName", getDormbuildName())
            .append("title", getTitle())
            .append("content", getContent())
            .append("state", getState())
            .append("orderBuildtime", getOrderBuildtime())
            .append("orderFinishtime", getOrderFinishtime())
            .toString();
    }
}
