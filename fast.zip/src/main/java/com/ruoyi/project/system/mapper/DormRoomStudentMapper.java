package com.ruoyi.project.system.mapper;

import java.util.List;
import com.ruoyi.project.system.domain.DormRoomStudent;

/**
 * 【请填写功能名称】Mapper接口
 * 
 * @author ruoyi
 * @date 2023-05-03
 */
public interface DormRoomStudentMapper 
{
    /**
     * 查询【请填写功能名称】
     * 
     * @param id 【请填写功能名称】主键
     * @return 【请填写功能名称】
     */
    public DormRoomStudent selectDormRoomStudentById(Long id);

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param dormRoomStudent 【请填写功能名称】
     * @return 【请填写功能名称】集合
     */
    public List<DormRoomStudent> selectDormRoomStudentList(DormRoomStudent dormRoomStudent);

    /**
     * 新增【请填写功能名称】
     * 
     * @param dormRoomStudent 【请填写功能名称】
     * @return 结果
     */
    public int insertDormRoomStudent(DormRoomStudent dormRoomStudent);

    /**
     * 修改【请填写功能名称】
     * 
     * @param dormRoomStudent 【请填写功能名称】
     * @return 结果
     */
    public int updateDormRoomStudent(DormRoomStudent dormRoomStudent);

    /**
     * 删除【请填写功能名称】
     * 
     * @param id 【请填写功能名称】主键
     * @return 结果
     */
    public int deleteDormRoomStudentById(Long id);

    /**
     * 批量删除【请填写功能名称】
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteDormRoomStudentByIds(Long[] ids);

    /**
     * 查询床位
     * @param dormRoomStudent
     * @return
     */
    public DormRoomStudent selectDormRoomStudentByBedNumber(DormRoomStudent dormRoomStudent);

    /**
     * 根据学号查询宿舍信息
     * @param studentNumber
     * @return
     */
    public DormRoomStudent selectDormRoomStudentByStudentNumber(String studentNumber);
}
