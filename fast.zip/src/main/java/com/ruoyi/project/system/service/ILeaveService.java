package com.ruoyi.project.system.service;

import java.util.List;
import com.ruoyi.project.system.domain.Leave;

/**
 * 【请填写功能名称】Service接口
 * 
 * @author ruoyi
 * @date 2023-05-09
 */
public interface ILeaveService 
{
    /**
     * 查询【请填写功能名称】
     * 
     * @param id 【请填写功能名称】主键
     * @return 【请填写功能名称】
     */
    public Leave selectLeaveById(Long id);

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param leave 【请填写功能名称】
     * @return 【请填写功能名称】集合
     */
    public List<Leave> selectLeaveList(Leave leave);

    /**
     * 新增【请填写功能名称】
     * 
     * @param leave 【请填写功能名称】
     * @return 结果
     */
    public int insertLeave(Leave leave);

    /**
     * 修改【请填写功能名称】
     * 
     * @param leave 【请填写功能名称】
     * @return 结果
     */
    public int updateLeave(Leave leave);

    /**
     * 批量删除【请填写功能名称】
     * 
     * @param ids 需要删除的【请填写功能名称】主键集合
     * @return 结果
     */
    public int deleteLeaveByIds(Long[] ids);

    /**
     * 删除【请填写功能名称】信息
     * 
     * @param id 【请填写功能名称】主键
     * @return 结果
     */
    public int deleteLeaveById(Long id);
}
