package com.ruoyi.project.system.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import com.ruoyi.framework.web.domain.BaseEntity;

/**
 * 【请填写功能名称】对象 stu_enter
 * 
 * @author ruoyi
 * @date 2023-05-11
 */
public class StuEnter extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** $column.columnComment */
    private Long id;

    /** 学号 */
    @Excel(name = "学号")
    private String studentNumber;

    /** 学生姓名 */
    @Excel(name = "学生姓名")
    private String studentName;

    /** 性别 */
    @Excel(name = "性别")
    private String studentSex;

    /** 楼栋 */
    @Excel(name = "楼栋")
    private Long dormbuildId;

    /** 宿舍房间号 */
    @Excel(name = "宿舍房间号")
    private Long dormroomId;

    /** 返校时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "返校时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date enterTime;

    /** 返校前住址 */
    @Excel(name = "返校前住址")
    private String enterAddress;

    /** 学生电话 */
    @Excel(name = "学生电话")
    private String studentPhone;

    /** 目的地 */
    @Excel(name = "目的地")
    private String destination;

    /** 专业 */
    @Excel(name = "专业")
    private String deptName;

    /** 班级 */
    @Excel(name = "班级")
    private String classN;

    /** 出发地 */
    @Excel(name = "出发地")
    private String placeOfDeparture;

    /** 到校时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "到校时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date enterTimeEnd;

    /** 中转地 */
    @Excel(name = "中转地")
    private String transfer;

    /** 交通工具（车次、班次） */
    @Excel(name = "交通工具", readConverterExp = "车=次、班次")
    private String vehicle;

    /** 健康状况 */
    @Excel(name = "健康状况")
    private String health;

    /** 审核状态 */
    @Excel(name = "审核状态")
    private String state;

    /** 是否作废 0 否 1 是 */
    private String delFlag;

    /** 身份证号 */
    @Excel(name = "身份证号")
    private String identifyNumber;

    private Long studentCounsellorId;


    @Excel(name = "返校时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date fdyHandleTime;

    private String fdyHandleOptions;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setStudentNumber(String studentNumber) 
    {
        this.studentNumber = studentNumber;
    }

    public String getStudentNumber() 
    {
        return studentNumber;
    }
    public void setStudentName(String studentName) 
    {
        this.studentName = studentName;
    }

    public String getStudentName() 
    {
        return studentName;
    }
    public void setStudentSex(String studentSex) 
    {
        this.studentSex = studentSex;
    }

    public String getStudentSex() 
    {
        return studentSex;
    }
    public void setDormbuildId(Long dormbuildId) 
    {
        this.dormbuildId = dormbuildId;
    }

    public Long getDormbuildId() 
    {
        return dormbuildId;
    }
    public void setDormroomId(Long dormroomId) 
    {
        this.dormroomId = dormroomId;
    }

    public Long getDormroomId() 
    {
        return dormroomId;
    }
    public void setEnterTime(Date enterTime) 
    {
        this.enterTime = enterTime;
    }

    public Date getEnterTime() 
    {
        return enterTime;
    }
    public void setEnterAddress(String enterAddress) 
    {
        this.enterAddress = enterAddress;
    }

    public String getEnterAddress() 
    {
        return enterAddress;
    }
    public void setStudentPhone(String studentPhone) 
    {
        this.studentPhone = studentPhone;
    }

    public String getStudentPhone() 
    {
        return studentPhone;
    }
    public void setDestination(String destination) 
    {
        this.destination = destination;
    }

    public String getDestination() 
    {
        return destination;
    }
    public void setDeptName(String deptName) 
    {
        this.deptName = deptName;
    }

    public String getDeptName() 
    {
        return deptName;
    }
    public void setClassN(String classN) 
    {
        this.classN = classN;
    }

    public String getClassN() 
    {
        return classN;
    }
    public void setPlaceOfDeparture(String placeOfDeparture) 
    {
        this.placeOfDeparture = placeOfDeparture;
    }

    public String getPlaceOfDeparture() 
    {
        return placeOfDeparture;
    }
    public void setEnterTimeEnd(Date enterTimeEnd) 
    {
        this.enterTimeEnd = enterTimeEnd;
    }

    public Date getEnterTimeEnd() 
    {
        return enterTimeEnd;
    }
    public void setTransfer(String transfer) 
    {
        this.transfer = transfer;
    }

    public String getTransfer() 
    {
        return transfer;
    }
    public void setVehicle(String vehicle) 
    {
        this.vehicle = vehicle;
    }

    public String getVehicle() 
    {
        return vehicle;
    }
    public void setHealth(String health) 
    {
        this.health = health;
    }

    public String getHealth() 
    {
        return health;
    }
    public void setState(String state) 
    {
        this.state = state;
    }

    public String getState() 
    {
        return state;
    }
    public void setDelFlag(String delFlag) 
    {
        this.delFlag = delFlag;
    }

    public String getDelFlag() 
    {
        return delFlag;
    }
    public void setIdentifyNumber(String identifyNumber) 
    {
        this.identifyNumber = identifyNumber;
    }

    public String getIdentifyNumber() 
    {
        return identifyNumber;
    }

    public Long getStudentCounsellorId() {
        return studentCounsellorId;
    }

    public void setStudentCounsellorId(Long studentCounsellorId) {
        this.studentCounsellorId = studentCounsellorId;
    }

    public Date getFdyHandleTime() {
        return fdyHandleTime;
    }

    public void setFdyHandleTime(Date fdyHandleTime) {
        this.fdyHandleTime = fdyHandleTime;
    }

    public String getFdyHandleOptions() {
        return fdyHandleOptions;
    }

    public void setFdyHandleOptions(String fdyHandleOptions) {
        this.fdyHandleOptions = fdyHandleOptions;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("studentNumber", getStudentNumber())
            .append("studentName", getStudentName())
            .append("studentSex", getStudentSex())
            .append("dormbuildId", getDormbuildId())
            .append("dormroomId", getDormroomId())
            .append("enterTime", getEnterTime())
            .append("enterAddress", getEnterAddress())
            .append("studentPhone", getStudentPhone())
            .append("destination", getDestination())
            .append("deptName", getDeptName())
            .append("classN", getClassN())
            .append("placeOfDeparture", getPlaceOfDeparture())
            .append("enterTimeEnd", getEnterTimeEnd())
            .append("transfer", getTransfer())
            .append("vehicle", getVehicle())
            .append("health", getHealth())
            .append("state", getState())
            .append("delFlag", getDelFlag())
            .append("identifyNumber", getIdentifyNumber())
            .append("studentCounsellorId", getStudentCounsellorId())
            .append("fdyHandleTime", getFdyHandleTime())
            .append("fdyHandleOptions", getFdyHandleOptions())
            .toString();
    }
}
