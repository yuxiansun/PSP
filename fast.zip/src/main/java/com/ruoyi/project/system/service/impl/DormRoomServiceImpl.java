package com.ruoyi.project.system.service.impl;

import java.util.List;

import com.ruoyi.project.system.domain.DormRoomStudent;
import com.ruoyi.project.system.mapper.DormRoomStudentMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.project.system.mapper.DormRoomMapper;
import com.ruoyi.project.system.domain.DormRoom;
import com.ruoyi.project.system.service.IDormRoomService;

/**
 * 【请填写功能名称】Service业务层处理
 * 
 * @author ruoyi
 * @date 2023-05-02
 */
@Service
public class DormRoomServiceImpl implements IDormRoomService 
{
    @Autowired
    private DormRoomMapper dormRoomMapper;

    @Autowired
    private DormRoomStudentMapper dormRoomStudentMapper;

    /**
     * 查询【请填写功能名称】
     * 
     * @param dormroomId 【请填写功能名称】主键
     * @return 【请填写功能名称】
     */
    @Override
    public DormRoom selectDormRoomByDormroomId(Long dormroomId)
    {
        return dormRoomMapper.selectDormRoomByDormroomId(dormroomId);
    }

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param dormRoom 【请填写功能名称】
     * @return 【请填写功能名称】
     */
    @Override
    public List<DormRoom> selectDormRoomList(DormRoom dormRoom)
    {
        return dormRoomMapper.selectDormRoomList(dormRoom);
    }

    /**
     * 新增【请填写功能名称】
     * 
     * @param dormRoom 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int insertDormRoom(DormRoom dormRoom)
    {
        DormRoomStudent dormRoomStudent = new DormRoomStudent();
        dormRoomStudent.setDormroomId(dormRoom.getDormroomId());
        dormRoomStudent.setDormbuildId(dormRoom.getDormbuildId());
        if (dormRoom.getFirstBed() != null && !dormRoom.getFirstBed().equals("")) {
            dormRoomStudent.setStudentNumber(dormRoom.getFirstBed());
            dormRoomStudent.setBedNumber(1);
            dormRoomStudentMapper.insertDormRoomStudent(dormRoomStudent);
        }
        if (dormRoom.getSecondBed() != null && !dormRoom.getSecondBed().equals("")) {
            dormRoomStudent.setStudentNumber(dormRoom.getSecondBed());
            dormRoomStudent.setBedNumber(2);
            dormRoomStudentMapper.insertDormRoomStudent(dormRoomStudent);
        }
        if (dormRoom.getThirdBed() != null && !dormRoom.getThirdBed().equals("")) {
            dormRoomStudent.setStudentNumber(dormRoom.getThirdBed());
            dormRoomStudent.setBedNumber(3);
            dormRoomStudentMapper.insertDormRoomStudent(dormRoomStudent);
        }
        if (dormRoom.getFourthBed() != null && !dormRoom.getFourthBed().equals("")) {
            dormRoomStudent.setStudentNumber(dormRoom.getFourthBed());
            dormRoomStudent.setBedNumber(4);
            dormRoomStudentMapper.insertDormRoomStudent(dormRoomStudent);
        }
        if (dormRoom.getFivethBed() != null && !dormRoom.getFivethBed().equals("")) {
            dormRoomStudent.setStudentNumber(dormRoom.getFivethBed());
            dormRoomStudent.setBedNumber(5);
            dormRoomStudentMapper.insertDormRoomStudent(dormRoomStudent);
        }
        if (dormRoom.getSixthBed() != null && !dormRoom.getSixthBed().equals("")) {
            dormRoomStudent.setStudentNumber(dormRoom.getSixthBed());
            dormRoomStudent.setBedNumber(6);
            dormRoomStudentMapper.insertDormRoomStudent(dormRoomStudent);
        }
        if (dormRoom.getSeventhBed() != null && !dormRoom.getSeventhBed().equals("")) {
            dormRoomStudent.setStudentNumber(dormRoom.getSeventhBed());
            dormRoomStudent.setBedNumber(7);
            dormRoomStudentMapper.insertDormRoomStudent(dormRoomStudent);
        }
        if (dormRoom.getEightBed() != null && !dormRoom.getEightBed().equals("")) {
            dormRoomStudent.setStudentNumber(dormRoom.getEightBed());
            dormRoomStudent.setBedNumber(8);
            dormRoomStudentMapper.insertDormRoomStudent(dormRoomStudent);
        }
        return dormRoomMapper.insertDormRoom(dormRoom);
    }

    /**
     * 修改【请填写功能名称】
     * 
     * @param dormRoom 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int updateDormRoom(DormRoom dormRoom)
    {
        DormRoomStudent dormRoomStudent = new DormRoomStudent();
        DormRoomStudent dormRoomStudent1;
        dormRoomStudent.setDormroomId(dormRoom.getDormroomId());
        dormRoomStudent.setDormbuildId(dormRoom.getDormbuildId());
        if (dormRoom.getFirstBed() != null && !dormRoom.getFirstBed().equals("")) {
            dormRoomStudent.setStudentNumber(dormRoom.getFirstBed());
            dormRoomStudent.setBedNumber(1);
            dormRoomStudent1 = dormRoomStudentMapper.selectDormRoomStudentByBedNumber(dormRoomStudent);
            if (dormRoomStudent1 == null) {
                dormRoomStudentMapper.insertDormRoomStudent(dormRoomStudent);
            } else {
                dormRoomStudentMapper.updateDormRoomStudent(dormRoomStudent);
            }
        }
        if (dormRoom.getSecondBed() != null && !dormRoom.getSecondBed().equals("")) {
            dormRoomStudent.setStudentNumber(dormRoom.getSecondBed());
            dormRoomStudent.setBedNumber(2);
            dormRoomStudent1 = dormRoomStudentMapper.selectDormRoomStudentByBedNumber(dormRoomStudent);
            if (dormRoomStudent1 == null) {
                dormRoomStudentMapper.insertDormRoomStudent(dormRoomStudent);
            } else {
                dormRoomStudentMapper.updateDormRoomStudent(dormRoomStudent);
            }
        }
        if (dormRoom.getThirdBed() != null && !dormRoom.getThirdBed().equals("")) {
            dormRoomStudent.setStudentNumber(dormRoom.getThirdBed());
            dormRoomStudent.setBedNumber(3);
            dormRoomStudent1 = dormRoomStudentMapper.selectDormRoomStudentByBedNumber(dormRoomStudent);
            if (dormRoomStudent1 == null) {
                dormRoomStudentMapper.insertDormRoomStudent(dormRoomStudent);
            } else {
                dormRoomStudentMapper.updateDormRoomStudent(dormRoomStudent);
            }
        }
        if (dormRoom.getFourthBed() != null && !dormRoom.getFourthBed().equals("")) {
            dormRoomStudent.setStudentNumber(dormRoom.getFourthBed());
            dormRoomStudent.setBedNumber(4);
            dormRoomStudent1 = dormRoomStudentMapper.selectDormRoomStudentByBedNumber(dormRoomStudent);
            if (dormRoomStudent1 == null) {
                dormRoomStudentMapper.insertDormRoomStudent(dormRoomStudent);
            } else {
                dormRoomStudentMapper.updateDormRoomStudent(dormRoomStudent);
            }
        }
        if (dormRoom.getFivethBed() != null && !dormRoom.getFivethBed().equals("")) {
            dormRoomStudent.setStudentNumber(dormRoom.getFivethBed());
            dormRoomStudent.setBedNumber(5);
            dormRoomStudent1 = dormRoomStudentMapper.selectDormRoomStudentByBedNumber(dormRoomStudent);
            if (dormRoomStudent1 == null) {
                dormRoomStudentMapper.insertDormRoomStudent(dormRoomStudent);
            } else {
                dormRoomStudentMapper.updateDormRoomStudent(dormRoomStudent);
            }
        }
        if (dormRoom.getSixthBed() != null && !dormRoom.getSixthBed().equals("")) {
            dormRoomStudent.setStudentNumber(dormRoom.getSixthBed());
            dormRoomStudent.setBedNumber(6);
            dormRoomStudent1 = dormRoomStudentMapper.selectDormRoomStudentByBedNumber(dormRoomStudent);
            if (dormRoomStudent1 == null) {
                dormRoomStudentMapper.insertDormRoomStudent(dormRoomStudent);
            } else {
                dormRoomStudentMapper.updateDormRoomStudent(dormRoomStudent);
            }
        }
        if (dormRoom.getSeventhBed() != null && !dormRoom.getSeventhBed().equals("")) {
            dormRoomStudent.setStudentNumber(dormRoom.getSeventhBed());
            dormRoomStudent.setBedNumber(7);
            dormRoomStudent1 = dormRoomStudentMapper.selectDormRoomStudentByBedNumber(dormRoomStudent);
            if (dormRoomStudent1 == null) {
                dormRoomStudentMapper.insertDormRoomStudent(dormRoomStudent);
            } else {
                dormRoomStudentMapper.updateDormRoomStudent(dormRoomStudent);
            }
        }
        if (dormRoom.getEightBed() != null && !dormRoom.getEightBed().equals("")) {
            dormRoomStudent.setStudentNumber(dormRoom.getEightBed());
            dormRoomStudent.setBedNumber(8);
            dormRoomStudent1 = dormRoomStudentMapper.selectDormRoomStudentByBedNumber(dormRoomStudent);
            if (dormRoomStudent1 == null) {
                dormRoomStudentMapper.insertDormRoomStudent(dormRoomStudent);
            } else {
                dormRoomStudentMapper.updateDormRoomStudent(dormRoomStudent);
            }
        }
        return dormRoomMapper.updateDormRoom(dormRoom);
    }

    /**
     * 批量删除【请填写功能名称】
     * 
     * @param dormroomIds 需要删除的【请填写功能名称】主键
     * @return 结果
     */
    @Override
    public int deleteDormRoomByDormroomIds(Long[] dormroomIds)
    {
        return dormRoomMapper.deleteDormRoomByDormroomIds(dormroomIds);
    }

    /**
     * 删除【请填写功能名称】信息
     * 
     * @param dormroomId 【请填写功能名称】主键
     * @return 结果
     */
    @Override
    public int deleteDormRoomByDormroomId(Long dormroomId)
    {
        return dormRoomMapper.deleteDormRoomByDormroomId(dormroomId);
    }
}
