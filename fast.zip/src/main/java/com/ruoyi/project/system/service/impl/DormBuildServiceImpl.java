package com.ruoyi.project.system.service.impl;

import java.util.List;

import com.ruoyi.common.constant.UserConstants;
import com.ruoyi.common.utils.StringUtils;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.project.system.mapper.DormBuildMapper;
import com.ruoyi.project.system.domain.DormBuild;
import com.ruoyi.project.system.service.IDormBuildService;

/**
 * 【请填写功能名称】Service业务层处理
 * 
 * @author ruoyi
 * @date 2023-05-02
 */
@Service
public class DormBuildServiceImpl implements IDormBuildService 
{
    @Autowired
    private DormBuildMapper dormBuildMapper;

    /**
     * 查询【请填写功能名称】
     * 
     * @param id 【请填写功能名称】主键
     * @return 【请填写功能名称】
     */
    @Override
    public DormBuild selectDormBuildById(Long id)
    {
        return dormBuildMapper.selectDormBuildById(id);
    }

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param dormBuild 【请填写功能名称】
     * @return 【请填写功能名称】
     */
    @Override
    public List<DormBuild> selectDormBuildList(DormBuild dormBuild)
    {
        List<DormBuild> list = dormBuildMapper.selectDormBuildList(dormBuild);
        return list;
    }

    /**
     * 新增【请填写功能名称】
     * 
     * @param dormBuild 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int insertDormBuild(DormBuild dormBuild)
    {
        dormBuild.setDelFlag('0');
        return dormBuildMapper.insertDormBuild(dormBuild);
    }

    /**
     * 修改【请填写功能名称】
     * 
     * @param dormBuild 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int updateDormBuild(DormBuild dormBuild)
    {
        dormBuild.setDelFlag('1');
        return dormBuildMapper.updateDormBuild(dormBuild);
    }

    /**
     * 批量删除【请填写功能名称】
     * 
     * @param ids 需要删除的【请填写功能名称】主键
     * @return 结果
     */
    @Override
    public int deleteDormBuildByIds(Long[] ids)
    {
        return dormBuildMapper.deleteDormBuildByIds(ids);
    }

    /**
     * 删除【请填写功能名称】信息
     * 
     * @param id 【请填写功能名称】主键
     * @return 结果
     */
    @Override
    public int deleteDormBuildById(Long id)
    {
        return dormBuildMapper.deleteDormBuildById(id);
    }

    @Override
    public boolean checkBuildNumberUnique(DormBuild dormBuild) {
        Long buildId = StringUtils.isNull(dormBuild.getDormbuildId()) ? -1L : dormBuild.getDormbuildId();
        System.out.println(dormBuild.getDormbuildId().toString());
        DormBuild buildInfo = dormBuildMapper.checkBuildNumberUnique(dormBuild.getDormbuildId());
        if (StringUtils.isNotNull(buildInfo) && buildInfo.getDormbuildId().longValue() == buildId.longValue() ) {
            return UserConstants.NOT_UNIQUE;
        }
        return UserConstants.UNIQUE;
    }
}
