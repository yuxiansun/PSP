package com.ruoyi.project.system.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import com.ruoyi.framework.web.domain.BaseEntity;

/**
 * 【请填写功能名称】对象 leave
 * 
 * @author ruoyi
 * @date 2023-05-09
 */
public class Leave extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** $column.columnComment */
    private Long id;

    /** 学号 */
    @Excel(name = "学号")
    private String studentNumber;

    /** 学生姓名 */
    @Excel(name = "学生姓名")
    private String studentName;

    /** 性别 */
    @Excel(name = "性别")
    private String studentSex;

    /** 楼栋 */
    @Excel(name = "楼栋")
    private Long dormbuildId;

    /** 宿舍房间号 */
    @Excel(name = "宿舍房间号")
    private Long dormroomId;

    /** 离校时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "离校时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date leaveTime;

    /** 离校去向 */
    @Excel(name = "离校去向")
    private String leaveDestination;

    /** 学生电话 */
    @Excel(name = "学生电话")
    private String studentPhone;

    /** 家人电话 */
    @Excel(name = "家人电话")
    private String familyPhone;

    /** 专业 */
    @Excel(name = "专业")
    private String deptName;

    /** 班级 */
    @Excel(name = "班级")
    private String classN;

    /** 家庭所在地 */
    @Excel(name = "家庭所在地")
    private String homeLocation;

    /** 宿舍管理员审核意见 */
    @Excel(name = "宿舍管理员审核意见")
    private String dormHandleOptions;

    /** 辅导员审核意见 */
    @Excel(name = "辅导员审核意见")
    private String fdyHandleOptions;

    /** 宿舍管理员审核时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "宿舍管理员审核时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date dormHandleTime;

    /** 辅导员审核时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "辅导员审核时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date fdyHandleTime;

    /** 审核状态 */
    @Excel(name = "审核状态")
    private String state;

    /** 处理详情 */
    @Excel(name = "处理详情")
    private String stateDetail;

    /** 是否作废 0 否 1 是 */
    private String delFlag;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setStudentNumber(String studentNumber) 
    {
        this.studentNumber = studentNumber;
    }

    public String getStudentNumber() 
    {
        return studentNumber;
    }
    public void setStudentName(String studentName) 
    {
        this.studentName = studentName;
    }

    public String getStudentName() 
    {
        return studentName;
    }
    public void setStudentSex(String studentSex) 
    {
        this.studentSex = studentSex;
    }

    public String getStudentSex() 
    {
        return studentSex;
    }
    public void setDormbuildId(Long dormbuildId) 
    {
        this.dormbuildId = dormbuildId;
    }

    public Long getDormbuildId() 
    {
        return dormbuildId;
    }
    public void setDormroomId(Long dormroomId) 
    {
        this.dormroomId = dormroomId;
    }

    public Long getDormroomId() 
    {
        return dormroomId;
    }
    public void setLeaveTime(Date leaveTime) 
    {
        this.leaveTime = leaveTime;
    }

    public Date getLeaveTime() 
    {
        return leaveTime;
    }
    public void setLeaveDestination(String leaveDestination) 
    {
        this.leaveDestination = leaveDestination;
    }

    public String getLeaveDestination() 
    {
        return leaveDestination;
    }
    public void setStudentPhone(String studentPhone) 
    {
        this.studentPhone = studentPhone;
    }

    public String getStudentPhone() 
    {
        return studentPhone;
    }
    public void setFamilyPhone(String familyPhone) 
    {
        this.familyPhone = familyPhone;
    }

    public String getFamilyPhone() 
    {
        return familyPhone;
    }
    public void setDeptName(String deptName) 
    {
        this.deptName = deptName;
    }

    public String getDeptName() 
    {
        return deptName;
    }

    public String getClassN() {
        return classN;
    }

    public Long studentCounsellorId;

    public void setClassN(String classN) {
        this.classN = classN;
    }

    public void setHomeLocation(String homeLocation)
    {
        this.homeLocation = homeLocation;
    }

    public String getHomeLocation() 
    {
        return homeLocation;
    }
    public void setDormHandleOptions(String dormHandleOptions) 
    {
        this.dormHandleOptions = dormHandleOptions;
    }

    public String getDormHandleOptions() 
    {
        return dormHandleOptions;
    }
    public void setFdyHandleOptions(String fdyHandleOptions) 
    {
        this.fdyHandleOptions = fdyHandleOptions;
    }

    public String getFdyHandleOptions() 
    {
        return fdyHandleOptions;
    }
    public void setDormHandleTime(Date dormHandleTime) 
    {
        this.dormHandleTime = dormHandleTime;
    }

    public Date getDormHandleTime() 
    {
        return dormHandleTime;
    }
    public void setFdyHandleTime(Date fdyHandleTime) 
    {
        this.fdyHandleTime = fdyHandleTime;
    }

    public Date getFdyHandleTime() 
    {
        return fdyHandleTime;
    }
    public void setState(String state) 
    {
        this.state = state;
    }

    public String getState() 
    {
        return state;
    }
    public void setStateDetail(String stateDetail) 
    {
        this.stateDetail = stateDetail;
    }

    public String getStateDetail() 
    {
        return stateDetail;
    }
    public void setDelFlag(String delFlag) 
    {
        this.delFlag = delFlag;
    }

    public String getDelFlag() 
    {
        return delFlag;
    }

    public Long getStudentCounsellorId() {
        return studentCounsellorId;
    }

    public void setStudentCounsellorId(Long studentCounsellorId) {
        this.studentCounsellorId = studentCounsellorId;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("studentNumber", getStudentNumber())
            .append("studentName", getStudentName())
            .append("studentSex", getStudentSex())
            .append("dormbuildId", getDormbuildId())
            .append("dormroomId", getDormroomId())
            .append("leaveTime", getLeaveTime())
            .append("leaveDestination", getLeaveDestination())
            .append("studentPhone", getStudentPhone())
            .append("familyPhone", getFamilyPhone())
            .append("deptName", getDeptName())
            .append("classN", getClassN())
            .append("homeLocation", getHomeLocation())
            .append("dormHandleOptions", getDormHandleOptions())
            .append("fdyHandleOptions", getFdyHandleOptions())
            .append("dormHandleTime", getDormHandleTime())
            .append("fdyHandleTime", getFdyHandleTime())
            .append("state", getState())
            .append("stateDetail", getStateDetail())
            .append("studentCounsellorId", getStudentCounsellorId())
            .append("delFlag", getDelFlag())
            .toString();
    }
}
