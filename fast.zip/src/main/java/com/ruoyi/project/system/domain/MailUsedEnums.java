package com.ruoyi.project.system.domain;

public enum MailUsedEnums {
    // 正常邮件
    NORMAL,
    /* 发送验证码 */
    CODE,
    /* 备份 */
    BACK_UP
}
