package com.ruoyi.project.system.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import com.ruoyi.framework.web.domain.BaseEntity;

/**
 * 【请填写功能名称】对象 message
 * 
 * @author ruoyi
 * @date 2023-05-04
 */
public class Message extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** $column.columnComment */
    private Long id;

    /** 留言标题 */
    @Excel(name = "留言标题")
    private String title;

    /** 留言内容 */
    @Excel(name = "留言内容")
    private String content;

    /** 留言时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "留言时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date date;

    /** 留言账号 */
    @Excel(name = "留言账号")
    private String account;

    /** 被留言人 */
    @Excel(name = "被留言人")
    private String accountTwo;

    /** 留言人名称 */
    @Excel(name = "留言人名称")
    private String accountName;

    /** 被留言人名称 */
    @Excel(name = "被留言人名称")
    private String accountTwoName;

    /** 回复内容 */
    @Excel(name = "回复内容")
    private String replayAccount;

    /** 回复时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "回复时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date replayTime;

    /** 是否删除 0 未删除  1 回复 2 删除 */
    private Integer delFlag;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setTitle(String title) 
    {
        this.title = title;
    }

    public String getTitle() 
    {
        return title;
    }
    public void setContent(String content) 
    {
        this.content = content;
    }

    public String getContent() 
    {
        return content;
    }
    public void setDate(Date date) 
    {
        this.date = date;
    }

    public Date getDate() 
    {
        return date;
    }
    public void setAccount(String account) 
    {
        this.account = account;
    }

    public String getAccount() 
    {
        return account;
    }
    public void setAccountTwo(String accountTwo) 
    {
        this.accountTwo = accountTwo;
    }

    public String getAccountTwo() 
    {
        return accountTwo;
    }
    public void setAccountName(String accountName) 
    {
        this.accountName = accountName;
    }

    public String getAccountName() 
    {
        return accountName;
    }
    public void setAccountTwoName(String accountTwoName) 
    {
        this.accountTwoName = accountTwoName;
    }

    public String getAccountTwoName() 
    {
        return accountTwoName;
    }
    public void setReplayAccount(String replayAccount) 
    {
        this.replayAccount = replayAccount;
    }

    public String getReplayAccount() 
    {
        return replayAccount;
    }
    public void setReplayTime(Date replayTime) 
    {
        this.replayTime = replayTime;
    }

    public Date getReplayTime() 
    {
        return replayTime;
    }
    public void setDelFlag(Integer delFlag) 
    {
        this.delFlag = delFlag;
    }

    public Integer getDelFlag() 
    {
        return delFlag;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("title", getTitle())
            .append("content", getContent())
            .append("date", getDate())
            .append("account", getAccount())
            .append("accountTwo", getAccountTwo())
            .append("accountName", getAccountName())
            .append("accountTwoName", getAccountTwoName())
            .append("replayAccount", getReplayAccount())
            .append("replayTime", getReplayTime())
            .append("delFlag", getDelFlag())
            .toString();
    }
}
