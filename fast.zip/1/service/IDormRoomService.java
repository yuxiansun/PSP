package com.ruoyi.project.system.service;

import java.util.List;
import com.ruoyi.project.system.domain.DormRoom;

/**
 * 【请填写功能名称】Service接口
 * 
 * @author ruoyi
 * @date 2023-05-02
 */
public interface IDormRoomService 
{
    /**
     * 查询【请填写功能名称】
     * 
     * @param dormroomId 【请填写功能名称】主键
     * @return 【请填写功能名称】
     */
    public DormRoom selectDormRoomByDormroomId(Long dormroomId);

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param dormRoom 【请填写功能名称】
     * @return 【请填写功能名称】集合
     */
    public List<DormRoom> selectDormRoomList(DormRoom dormRoom);

    /**
     * 新增【请填写功能名称】
     * 
     * @param dormRoom 【请填写功能名称】
     * @return 结果
     */
    public int insertDormRoom(DormRoom dormRoom);

    /**
     * 修改【请填写功能名称】
     * 
     * @param dormRoom 【请填写功能名称】
     * @return 结果
     */
    public int updateDormRoom(DormRoom dormRoom);

    /**
     * 批量删除【请填写功能名称】
     * 
     * @param dormroomIds 需要删除的【请填写功能名称】主键集合
     * @return 结果
     */
    public int deleteDormRoomByDormroomIds(Long[] dormroomIds);

    /**
     * 删除【请填写功能名称】信息
     * 
     * @param dormroomId 【请填写功能名称】主键
     * @return 结果
     */
    public int deleteDormRoomByDormroomId(Long dormroomId);
}
