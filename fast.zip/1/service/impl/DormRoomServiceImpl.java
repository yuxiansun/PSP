package com.ruoyi.project.system.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.project.system.mapper.DormRoomMapper;
import com.ruoyi.project.system.domain.DormRoom;
import com.ruoyi.project.system.service.IDormRoomService;

/**
 * 【请填写功能名称】Service业务层处理
 * 
 * @author ruoyi
 * @date 2023-05-02
 */
@Service
public class DormRoomServiceImpl implements IDormRoomService 
{
    @Autowired
    private DormRoomMapper dormRoomMapper;

    /**
     * 查询【请填写功能名称】
     * 
     * @param dormroomId 【请填写功能名称】主键
     * @return 【请填写功能名称】
     */
    @Override
    public DormRoom selectDormRoomByDormroomId(Long dormroomId)
    {
        return dormRoomMapper.selectDormRoomByDormroomId(dormroomId);
    }

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param dormRoom 【请填写功能名称】
     * @return 【请填写功能名称】
     */
    @Override
    public List<DormRoom> selectDormRoomList(DormRoom dormRoom)
    {
        return dormRoomMapper.selectDormRoomList(dormRoom);
    }

    /**
     * 新增【请填写功能名称】
     * 
     * @param dormRoom 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int insertDormRoom(DormRoom dormRoom)
    {
        return dormRoomMapper.insertDormRoom(dormRoom);
    }

    /**
     * 修改【请填写功能名称】
     * 
     * @param dormRoom 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int updateDormRoom(DormRoom dormRoom)
    {
        return dormRoomMapper.updateDormRoom(dormRoom);
    }

    /**
     * 批量删除【请填写功能名称】
     * 
     * @param dormroomIds 需要删除的【请填写功能名称】主键
     * @return 结果
     */
    @Override
    public int deleteDormRoomByDormroomIds(Long[] dormroomIds)
    {
        return dormRoomMapper.deleteDormRoomByDormroomIds(dormroomIds);
    }

    /**
     * 删除【请填写功能名称】信息
     * 
     * @param dormroomId 【请填写功能名称】主键
     * @return 结果
     */
    @Override
    public int deleteDormRoomByDormroomId(Long dormroomId)
    {
        return dormRoomMapper.deleteDormRoomByDormroomId(dormroomId);
    }
}
