import request from '@/utils/request'

// 查询【请填写功能名称】列表
export function listVisitor(query) {
  return request({
    url: '/system/visitor/list',
    method: 'get',
    params: query
  })
}

// 查询【请填写功能名称】详细
export function getVisitor(id) {
  return request({
    url: '/system/visitor/' + id,
    method: 'get'
  })
}

// 新增【请填写功能名称】
export function addVisitor(data) {
  return request({
    url: '/system/visitor',
    method: 'post',
    data: data
  })
}

// 修改【请填写功能名称】
export function updateVisitor(data) {
  return request({
    url: '/system/visitor',
    method: 'put',
    data: data
  })
}

// 删除【请填写功能名称】
export function delVisitor(id) {
  return request({
    url: '/system/visitor/' + id,
    method: 'delete'
  })
}
