import request from '@/utils/request'

// 查询【请填写功能名称】列表
export function listRoom(query) {
  return request({
    url: '/system/dormroom/list',
    method: 'get',
    params: query
  })
}

// 查询【请填写功能名称】详细
export function getRoom(id) {
  return request({
    url: '/system/dormroom/' + id,
    method: 'get'
  })
}

// 新增【请填写功能名称】
export function addRoom(data) {
  return request({
    url: '/system/dormroom',
    method: 'post',
    data: data
  })
}

// 修改【请填写功能名称】
export function updateRoom(data) {
  return request({
    url: '/system/dormroom',
    method: 'put',
    data: data
  })
}

// 删除【请填写功能名称】
export function delRoom(id) {
  return request({
    url: '/system/dormroom/' + id,
    method: 'delete'
  })
}

export function getStudentRoom(studentNumber) {
  return request({
    url: '/system/student/student/' + studentNumber,
    method: 'get'
  })
}