import request from '@/utils/request'

// 查询【请填写功能名称】列表
export function listSanitation(query) {
  return request({
    url: '/system/sanitation/list',
    method: 'get',
    params: query
  })
}

// 查询【请填写功能名称】详细
export function getSanitation(id) {
  return request({
    url: '/system/sanitation/' + id,
    method: 'get'
  })
}

// 新增【请填写功能名称】
export function addSanitation(data) {
  return request({
    url: '/system/sanitation',
    method: 'post',
    data: data
  })
}

// 修改【请填写功能名称】
export function updateSanitation(data) {
  return request({
    url: '/system/sanitation',
    method: 'put',
    data: data
  })
}

// 删除【请填写功能名称】
export function delSanitation(id) {
  return request({
    url: '/system/sanitation/' + id,
    method: 'delete'
  })
}
