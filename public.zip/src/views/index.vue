<template>
  <div class="app-container home">
    <el-row>
      <el-col>
        欢迎使用宿舍管理系统
      </el-col>
    </el-row>
    <el-divider />
    <div v-if="user.roleId == 100">
      <el-row :gutter="20">
        <el-col :span="12" :xs="24">
          <el-card class="box-card">
            <div slot="header" class="clearfix">
              <span style="line-height: 30px">个人信息</span>
            </div>
            <div>
              <ul class="list-group list-group-striped">
                <li class="list-group-item">
                  <svg-icon icon-class="user" />用户名称
                  <div class="pull-right">{{ user.userName }}</div>
                </li>
                <li class="list-group-item" v-if="user.studentNumber">
                  用户学号
                  <div class="pull-right">{{ user.studentNumber }}</div>
                </li>
                <li class="list-group-item" v-if="user.identifyNumber">
                  身份证号
                  <div class="pull-right">{{ user.identifyNumber }}</div>
                </li>
                <li class="list-group-item" v-if="user.deptName">
                  专业名称
                  <div class="pull-right">{{ user.deptName }}</div>
                </li>
                <li class="list-group-item" v-if="user.className">
                  所在班级
                  <div class="pull-right">{{ user.className }}</div>
                </li>
                <!-- <li class="list-group-item">
                  住宿信息
                  <div class="pull-right">
                    <span @click="showDormitoryInfo" style="color:brown">查看宿舍信息</span>
                  </div>
                </li> -->
                <li class="list-group-item">
                  <svg-icon icon-class="phone" />手机号码
                  <div class="pull-right">{{ user.phonenumber }}</div>
                </li>
                <li class="list-group-item">
                  <svg-icon icon-class="email" />用户邮箱
                  <div class="pull-right">{{ user.email }}</div>
                </li>
                <li class="list-group-item">
                  <svg-icon icon-class="tree" />所属学院
                  <div class="pull-right" v-if="user.dept">{{ user.dept.deptName }}</div>
                </li>
                <li class="list-group-item">
                  <svg-icon icon-class="peoples" />所属角色
                  <div class="pull-right">{{ roleGroup }}</div>
                </li>
                <li class="list-group-item">
                  <svg-icon icon-class="date" />创建日期
                  <div class="pull-right">{{ user.createTime }}</div>
                </li>
              </ul>
            </div>
          </el-card>
        </el-col>
        <el-col :span="12" :xs="24">
          <el-card class="box-card">
            <div slot="header" class="clearfix">
              <span style="line-height: 30px">宿舍信息</span>
            </div>
            <div>
              <ul class="list-group list-group-striped">
                <li class="list-group-item">
                  楼栋
                  <div class="pull-right">{{ dormitoryForm.dormbuildName }}</div>
                </li>
                <li class="list-group-item">
                  房间号
                  <div class="pull-right">{{ dormitoryForm.dormroomId }}</div>
                </li>
                <li class="list-group-item">
                  床位
                  <div class="pull-right">{{ dormitoryForm.bedNumber }}</div>
                </li>
              </ul>
            </div>
          </el-card>
        </el-col>
      </el-row>
      <el-row :gutter="20" style="margin-top: 20px">
        <el-col :span="24">
          <el-card class="box-card">
            <div slot="header" class="clearfix">
              <span style="line-height: 30px">通知公告</span>
            </div>
            <div>
              <ul v-if="noticeList.length > 0" class="list-group list-group-striped">
                <li @click="handleView(item)" v-for="item in noticeList" :key="item.id" class="list-group-item">
                  <span>
                    {{ item.noticeType }}
                  </span>
                  {{ item.noticeTitle }}
                </li>
              </ul>
              <div v-else>
                暂时还没有通知公告哦^-^
              </div>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>
    <el-dialog :visible.sync="open" append-to-body title="住宿信息">
      <el-form :model="dormitoryForm">
        <el-form-item label="楼栋">
          <span>{{ dormitoryForm.dormbuildName }}</span>
        </el-form-item>
        <el-form-item label="宿舍房间">
          <span>{{ dormitoryForm.dormroomId }}</span>
        </el-form-item>
        <el-form-item label="床位">
          <span>{{ dormitoryForm.bedNumber }}</span>
        </el-form-item>
      </el-form>
    </el-dialog>
    <!-- 添加或修改公告对话框 -->
    <el-dialog :title="title" :visible.sync="open2" width="780px" append-to-body>
      <el-form ref="form" :model="formNotice" label-width="80px">
        <el-row>
          <el-col :span="24">
            标题：{{ formNotice.noticeTitle }}
          </el-col>
          <el-col :span="24">
            内容：{{ formNotice.noticeContent }}
          </el-col>
        </el-row>
      </el-form>
    </el-dialog>
  </div>
</template>

<script>
import { getUserProfile } from "@/api/system/user";
import { getStudentRoom } from "@/api/system/room";
import { listNotice, getNotice, delNotice, addNotice, updateNotice } from "@/api/system/notice";
export default {
  name: "Index",
  data() {
    return {
      // 版本号
      version: "3.8.5",
      user: {},
      roleGroup: {},
      postGroup: {},
      activeTab: "userinfo",
      open: false,
      dormitoryForm: {},
      noticeList: [],
      open2: false,
      formNotice: {},
      title: ''
    };
  },
  created() {
    this.getUser();
    this.getListNotice()
    setInterval(() => {
      this.getListNotice()
    }, 5000);
  },
  methods: {
    getUser() {
      getUserProfile().then(response => {
        this.user = response.data;
        this.roleGroup = response.roleGroup;
        this.postGroup = response.postGroup;
        if (this.user.studentNumber) {
          this.showDormitoryInfo();
        }
      });
    },
    showDormitoryInfo() {
      // 查询住宿信息
      getStudentRoom(this.user.studentNumber).then(res => {
        this.dormitoryForm = res.data;
      })
    },
    goTarget(href) {
      window.open(href, "_blank");
    },
    getListNotice() {
      listNotice({ pageNum: 1, pageSize: 10 }).then(res => {
        this.noticeList = res.rows;
      })
    },
    reset() { 
      this.formNotice = {}
    },
    handleView(row) {
      this.reset();
      const noticeId = row.noticeId || this.ids
      getNotice(noticeId).then(response => {
        this.formNotice = response.data;
        this.open2 = true;
        this.title = "查看公告详情";
      });
    }
  }
};
</script>

<style scoped lang="scss">
.home {
  blockquote {
    padding: 10px 20px;
    margin: 0 0 20px;
    font-size: 17.5px;
    border-left: 5px solid #eee;
  }

  hr {
    margin-top: 20px;
    margin-bottom: 20px;
    border: 0;
    border-top: 1px solid #eee;
  }

  .col-item {
    margin-bottom: 20px;
  }

  ul {
    padding: 0;
    margin: 0;
  }

  font-family: "open sans",
  "Helvetica Neue",
  Helvetica,
  Arial,
  sans-serif;
  font-size: 13px;
  color: #676a6c;
  overflow-x: hidden;

  ul {
    list-style-type: none;
  }

  h4 {
    margin-top: 0px;
  }

  h2 {
    margin-top: 10px;
    font-size: 26px;
    font-weight: 100;
  }

  p {
    margin-top: 10px;

    b {
      font-weight: 700;
    }
  }

  .update-log {
    ol {
      display: block;
      list-style-type: decimal;
      margin-block-start: 1em;
      margin-block-end: 1em;
      margin-inline-start: 0;
      margin-inline-end: 0;
      padding-inline-start: 30px;
    }
  }
}

.list-group-item {
  line-height: 30px;
}
</style>

