<template>
  <div>
    <el-breadcrumb separator-icon="ArrowRight" style="margin: 16px">
      <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item>宿舍管理</el-breadcrumb-item>
      <el-breadcrumb-item>房间信息</el-breadcrumb-item>
    </el-breadcrumb>
    <el-card style="margin: 15px; min-height: calc(100vh - 111px)">
      <div>
        <!--    功能区-->
        <div style="margin: 10px 0">
          <!--    搜索区-->
          <div style="margin: 10px 0">
            <el-input v-model="search" clearable placeholder="请输入房间号" prefix-icon="Search" style="width: 20%"/>
            <el-button icon="Search" style="margin-left: 5px" type="primary" @click="load"></el-button>
            <el-button icon="refresh-left" style="margin-left: 10px" type="default" @click="reset"></el-button>
            <div style="float: right">
              <el-tooltip content="添加" placement="top">
                <el-button icon="plus" style="width: 50px" type="primary" @click="add"></el-button>
              </el-tooltip>
            </div>
          </div>
        </div>
        <!--    表格-->
        <el-table v-loading="loading" :data="tableData" border max-height="705" style="width: 100%">
          <el-table-column label="#" type="index"/>
          <!-- 床位展开-->
          <el-table-column type="expand">
            <template #default="props">
              <el-form inline label-position="left">
                <el-form-item label="一号床位" class="item">
                  <template #default="scope">
                    <el-tag v-if="props.row.firstBed != null" disable-transitions type="primary"
                    >{{ props.row.firstBed }}
                    </el-tag>
                    <div class="el-form--inline-icon">
                      <el-icon v-if="props.row.firstBed == null" @click="plusIcon(1, props.row)">
                        <plus/>
                      </el-icon>
                      <div v-if="props.row.firstBed != null" class="el-form--inline-icon">
                        <el-icon @click="detailIcon(1, props.row)">
                          <more-filled/>
                        </el-icon>
                        <el-icon @click="editIcon(1, props.row)">
                          <edit/>
                        </el-icon>
                        <el-popconfirm title="确认删除？" @confirm="deleteStuBed(1, props.row)">
                          <template #reference>
                            <el-icon>
                              <delete/>
                            </el-icon>
                          </template>
                        </el-popconfirm>
                      </div>
                    </div>
                  </template>
                </el-form-item>
                <el-form-item label="二号床位" class="item">
                  <template #default="scope">
                    <el-tag v-if="props.row.secondBed != null" disable-transitions type="primary"
                    >{{ props.row.secondBed }}
                    </el-tag>
                    <div class="el-form--inline-icon">
                      <el-icon v-if="props.row.secondBed == null" @click="plusIcon(2, props.row)">
                        <plus/>
                      </el-icon>
                      <div v-if="props.row.secondBed != null" class="el-form--inline-icon">
                        <el-icon @click="detailIcon(2, props.row)">
                          <more-filled/>
                        </el-icon>
                        <el-icon @click="editIcon(2, props.row)">
                          <edit/>
                        </el-icon>
                        <el-popconfirm title="确认删除？" @confirm="deleteStuBed(2, props.row)">
                          <template #reference>
                            <el-icon>
                              <delete/>
                            </el-icon>
                          </template>
                        </el-popconfirm>
                      </div>
                    </div>
                  </template>
                </el-form-item>
                <el-form-item label="三号床位" class="item">
                  <template #default="scope">
                    <el-tag v-if="props.row.thirdBed != null" disable-transitions type="primary"
                    >{{ props.row.thirdBed }}
                    </el-tag>
                    <div class="el-form--inline-icon">
                      <el-icon v-if="props.row.thirdBed == null" @click="plusIcon(3, props.row)">
                        <plus/>
                      </el-icon>
                      <div v-if="props.row.thirdBed != null" class="el-form--inline-icon">
                        <el-icon @click="detailIcon(3, props.row)">
                          <more-filled/>
                        </el-icon>
                        <el-icon @click="editIcon(3, props.row)">
                          <edit/>
                        </el-icon>
                        <el-popconfirm title="确认删除？" @confirm="deleteStuBed(3, props.row)">
                          <template #reference>
                            <el-icon>
                              <delete/>
                            </el-icon>
                          </template>
                        </el-popconfirm>
                      </div>
                    </div>
                  </template>
                </el-form-item>
                <el-form-item label="四号床位" class="item">
                  <template #default="scope">
                    <el-tag v-if="props.row.fourthBed != null" disable-transitions type="primary"
                    >{{ props.row.fourthBed }}
                    </el-tag>
                    <div class="el-form--inline-icon">
                      <el-icon v-if="props.row.fourthBed == null" @click="plusIcon(4, props.row)">
                        <plus/>
                      </el-icon>
                      <div v-if="props.row.fourthBed != null" class="el-form--inline-icon">
                        <el-icon @click="detailIcon(4, props.row)">
                          <more-filled/>
                        </el-icon>
                        <el-icon @click="editIcon(4, props.row)">
                          <edit/>
                        </el-icon>
                        <el-popconfirm title="确认删除？" @confirm="deleteStuBed(4, props.row)">
                          <template #reference>
                            <el-icon>
                              <delete/>
                            </el-icon>
                          </template>
                        </el-popconfirm>
                      </div>
                    </div>
                  </template>
                </el-form-item>
              </el-form>
            </template>
          </el-table-column>
          <el-table-column label="房间号" prop="dormRoomId" sortable/>
          <el-table-column label="楼栋号" prop="dormBuildId" sortable/>
          <el-table-column label="楼层" prop="floorNum" sortable/>
          <el-table-column label="最多可住人数" prop="maxCapacity"/>
          <el-table-column
              :filter-method="filterTag"
              :filters="[
              { text: 0, value: 0 },
              { text: 1, value: 1 },
              { text: 2, value: 2 },
              { text: 3, value: 3 },
              { text: 4, value: 4 },
            ]"
              filter-placement="bottom-end"
              label="已住人数"
              prop="currentCapacity"
              sortable
          />
          <el-table-column
            label="操作"
            align="center"
            width="160"
            class-name="small-padding fixed-width"
          >
            <template slot-scope="scope" v-if="scope.row.userId !== 1">
              <el-button
                size="mini"
                type="text"
                icon="el-icon-edit"
                @click="handleEdit(scope.row)"
                v-hasPermi="['system:user:edit']"
              >修改</el-button>
              <el-button
                size="mini"
                type="text"
                icon="el-icon-delete"
                @click="handleDelete(scope.row)"
                v-hasPermi="['system:user:remove']"
              >删除</el-button>
            </template>
          </el-table-column>
          <!--      操作栏-->
          <!-- <el-table-column label="操作" width="130px">
            <template #default="scope">
              <el-button icon="Edit" type="primary" @click="handleEdit(scope.row)"
              ></el-button>
              <el-popconfirm title="确认删除？" @confirm="handleDelete(scope.row.dormRoomId)">
                <template #reference>
                  <el-button icon="Delete" type="danger"></el-button>
                </template>
              </el-popconfirm>
            </template>
          </el-table-column> -->
        </el-table>
        <!--分页-->
        <div style="margin: 10px 0">
          <pagination
            v-show="total>0"
            :total="total"
            :page.sync="queryParams.pageNum"
            :limit.sync="queryParams.pageSize"
            @pagination="getList"
          />
        </div>
        <!--      弹窗-->
        <div>
          <el-dialog v-model="dialogVisible" title="操作" width="30%" @close="cancel">
            <el-form ref="form" :model="form" :rules="rules" label-width="120px">
              <el-form-item label="楼栋号" prop="dormBuildId">
                <el-input v-model.number="form.dormBuildId" style="width: 80%"></el-input>
              </el-form-item>
              <el-form-item label="楼层数" prop="floorNum">
                <el-input v-model.number="form.floorNum" style="width: 80%"></el-input>
              </el-form-item>
              <el-form-item label="房间号" prop="dormRoomId">
                <el-input v-model.number="form.dormRoomId" :disabled="disabled" style="width: 80%"></el-input>
              </el-form-item>
              <el-form-item label="最多可住人数" prop="maxCapacity">
                <el-input v-model.number="form.maxCapacity" style="width: 80%"></el-input>
              </el-form-item>
              <el-form-item label="已住人数" prop="currentCapacity">
                <el-input v-model.number="form.currentCapacity" style="width: 80%"></el-input>
              </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
              <el-button @click="cancel">取 消</el-button>
              <el-button type="primary" @click="save">确 定</el-button>
            </div>
          </el-dialog>
          <!-- 床位 弹窗-->
          <el-dialog :visible.sync="bedDialog" title="操作" width="30%" @close="cancel">
            <el-form ref="form" :model="form" :rules="rules" label-width="120px">
              <el-form-item label="楼栋号" prop="dormBuildId">
                <el-input v-model.number="form.dormBuildId" disabled="true" style="width: 80%"></el-input>
              </el-form-item>
              <el-form-item label="楼层数" prop="floorNum">
                <el-input v-model.number="form.floorNum" disabled="true" style="width: 80%"></el-input>
              </el-form-item>
              <el-form-item label="房间号" prop="dormRoomId">
                <el-input v-model.number="form.dormRoomId" disabled="true" style="width: 80%"></el-input>
              </el-form-item>
              <el-form-item v-if="this.bedNum === 1" label="床位(一)" prop="firstBed">
                <el-input v-model.number="form.firstBed" placeholder="请输入学号" style="width: 80%"></el-input>
              </el-form-item>
              <el-form-item v-if="this.bedNum === 2" label="床位(二)" prop="secondBed">
                <el-input v-model.number="form.secondBed" placeholder="请输入学号" style="width: 80%"></el-input>
              </el-form-item>
              <el-form-item v-if="this.bedNum === 3" label="床位(三)" prop="thirdBed">
                <el-input v-model.number="form.thirdBed" placeholder="请输入学号" style="width: 80%"></el-input>
              </el-form-item>
              <el-form-item v-if="this.bedNum === 4" label="床位(四)" prop="fourthBed">
                <el-input v-model.number="form.fourthBed" placeholder="请输入学号" style="width: 80%"></el-input>
              </el-form-item>
            </el-form>
            <div slot="footer">
              <span class="dialog-footer">
                <el-button @click="cancel">取 消</el-button>
                <el-button v-if="this.judge === false" type="primary" @click="addStuBed">确 定</el-button>
                <el-button v-if="this.judge === true" type="primary" @click="editStuBed">确 定</el-button>
              </span>
            </div>
          </el-dialog>
          <!-- 学生信息弹窗-->
          <el-dialog :visible.sync="stuInfoDialog" title="学生信息" width="20%" @close="cancel">
            <el-form ref="form" :model="form" label-width="120px">
              <el-form-item label="学号：" prop="username">
                <span>{{ form.username }}</span>
              </el-form-item>
              <el-form-item label="姓名：" prop="name">
                <span>{{ form.name }}</span>
              </el-form-item>
              <el-form-item label="年龄：" prop="age">
                  <span>{{ form.age }}</span>
              </el-form-item>
              <el-form-item label="性别：" prop="gender">
                  <span>{{ form.gender }}</span>
              </el-form-item>
              <el-form-item label="手机号：" prop="phoneNum">
                  <span>{{ form.phoneNum }}</span>
              </el-form-item>
              <el-form-item label="邮箱地址：" prop="email">
                  <span>{{ form.email }}</span>
              </el-form-item>
            </el-form>
          </el-dialog>
        </div>
      </div>
    </el-card>
  </div>
</template>
<script>
import request from "@/utils/request";

const {ElMessage} = require("element-ui");
import { listBuild } from "@/api/system/build";

export default {
    name: "BuildingInfo",
    components: {},
    data() {
        const checkStuNum = (rule, value, callback) => {
            request.get("/stu/exist/" + value).then((res) => {
                request.get("/room/judgeHadBed/" + value).then((result) => {
                    if (res.code === "0" && result.code === "0") {
                        callback();
                    } else if (res.code === "-1" && result.code === "0") {
                        callback(new Error(res.msg));
                    } else if (res.code === "0" && result.code === "-1") {
                        callback(new Error(result.msg));
                    } else {
                        callback(new Error("请输入正确的数据"));
                    }
                });
            });
        };
        return {
            bedNum: 0,
            havePeopleNum: 0,
            loading: true,
            disabled: false,
            judge: false,
            dialogVisible: false,
            bedDialog: false,
            stuInfoDialog: false,
            bedName: "",
            search: "",
            currentPage: 1,
            pageSize: 10,
            total: 0,
            tableData: [],
            form: {
                dormRoomId: "",
                dormBuildId: "",
                floorNum: "",
                maxCapacity: "",
                currentCapacity: "",
                firstBed: "",
                secondBed: "",
                thirdBed: "",
                fourthBed: "",
            },
            rules: {
                dormRoomId: [
                    {required: true, message: "请输入房间号", trigger: "blur"},
                    {pattern: /^[0-9]{4}$/, message: "范围：1000-9999", trigger: "blur"},
                ],
                floorNum: [
                    {required: true, message: "请输入楼层数", trigger: "blur"},
                    {pattern: /^[1-3]$/, message: "范围：1-3", trigger: "blur"},
                ],
                dormBuildId: [
                    {required: true, message: "请输入楼宇号数", trigger: "blur"},
                    {pattern: /^[1-4]$/, message: "范围：1-4", trigger: "blur"},
                ],
                maxCapacity: [
                    {required: true, message: "请输入房间可住人数", trigger: "blur"},
                    {pattern: /^[0-4]$/, message: "范围：0-4", trigger: "blur"},
                ],
                currentCapacity: [
                    {required: true, message: "请输入当前已住人数", trigger: "blur"},
                    {pattern: /^[0-4]$/, message: "范围：0-4", trigger: "blur"},
                ],
                firstBed: [{validator: checkStuNum, trigger: "blur"}],
                secondBed: [{validator: checkStuNum, trigger: "blur"}],
                thirdBed: [{validator: checkStuNum, trigger: "blur"}],
                fourthBed: [{validator: checkStuNum, trigger: "blur"}],
          },
          buildList: []
        };
    },
    created() {
        this.load();
        this.loading = true;
        setTimeout(() => {
            //设置延迟执行
            this.loading = false;
        }, 1000);
      this.getBuildList();
    },
  methods: {
    getBuildList() { 
        listBuild({
          pageNum: 1,
          pageSize: 200,
        }).then(response => {
          this.buildList = response.rows;
        })
    },
        async load() {
            request.get("/room/find", {
                params: {
                    pageNum: this.currentPage,
                    pageSize: this.pageSize,
                    search: this.search,
                },
            }).then((res) => {
                this.tableData = res.data.records;
                this.total = res.data.total;
                this.loading = false;
            });
        },
        reset() {
            this.search = ''
            request.get("/room/find", {
                params: {
                    pageNum: 1,
                    pageSize: this.pageSize,
                    search: this.search,
                },
            }).then((res) => {
                console.log(res);
                this.tableData = res.data.records;
                this.total = res.data.total;
                this.loading = false;
            });
        },
        filterTag(value, row) {
            return row.currentCapacity === value;
        },
        add() {
            this.dialogVisible = true;
            this.$nextTick(() => {
                this.$refs.form.resetFields();
                this.disabled = false;
                this.form = {};
                this.judge = false;
            });
        },
        save() {
            this.$refs.form.validate(async (valid) => {
                if (valid) {
                    if (this.judge === false) {
                        //新增
                        request.post("/room/add", this.form).then((res) => {
                            if (res.code === "0") {
                                ElMessage({
                                    message: "新增成功",
                                    type: "success",
                                });
                                this.search = "";
                                this.loading = true;
                                this.load();
                                this.dialogVisible = false;
                            } else {
                                ElMessage({
                                    message: res.msg,
                                    type: "error",
                                });
                            }
                        });
                    } else {
                        //修改
                        request.put("/room/update", this.form).then((res) => {
                            if (res.code === "0") {
                                ElMessage({
                                    message: "修改成功",
                                    type: "success",
                                });
                                this.search = "";
                                this.load();
                                this.dialogVisible = false;
                            } else {
                                ElMessage({
                                    message: res.msg,
                                    type: "error",
                                });
                            }
                        });
                    }
                }
            });
        },
        cancel() {
            this.$refs.form.resetFields();
            this.dialogVisible = false;
            this.bedDialog = false;
            this.stuInfoDialog = false;
        },
        handleEdit(row) {
            //修改
            this.judge = true;
            this.dialogVisible = true;
            this.$nextTick(() => {
                this.$refs.form.resetFields();
                // 生拷贝
                this.form = JSON.parse(JSON.stringify(row));
                this.disabled = true;
            });
        },
        handleDelete(dormRoomId) {
            //删除
            request.delete("/room/delete/" + dormRoomId).then((res) => {
                if (res.code === "0") {
                    ElMessage({
                        message: "删除成功",
                        type: "success",
                    });
                    this.search = "";
                    this.load();
                } else {
                    ElMessage({
                        message: res.msg,
                        type: "error",
                    });
                }
            });
        },
        calCurrentNum(info) {
            this.havePeopleNum = 0;
            // 获取房间人数
            let roomPeopleNum = 0;
            if (info.firstBed != null) {
                roomPeopleNum++;
            }
            if (info.secondBed != null) {
                roomPeopleNum++;
            }
            if (info.thirdBed != null) {
                roomPeopleNum++;
            }
            if (info.fourthBed != null) {
                roomPeopleNum++;
            }
            this.havePeopleNum = roomPeopleNum;
        },
        plusIcon(num, info) {
            //添加图标
            this.judge = false;
            //显示对应床位input
            this.bedNum = num;
            //获取当前房间人数
            this.calCurrentNum(info);
            this.bedDialog = true;
            this.$nextTick(() => {
                this.$refs.form.resetFields();
                // 生拷贝
                this.form = JSON.parse(JSON.stringify(info));
            });
        },
        editIcon(num, info) {
            //修改图标
            this.judge = true;
            //显示对应床位input
            this.bedNum = num;
            //修改床位所住的学生
            this.bedDialog = true;
            this.$nextTick(() => {
                this.$refs.form.resetFields();
                // 生拷贝
                this.form = JSON.parse(JSON.stringify(info));
            });
        },
        detailIcon(num, info) {
            //查看床位所住的学生
            let stu = "";
            // 删除
            if (num === 1) {
                stu = info.firstBed;
            } else if (num === 2) {
                stu = info.secondBed;
            } else if (num === 3) {
                stu = info.thirdBed;
            } else if (num === 4) {
                stu = info.fourthBed;
            }
            request.get("/stu/exist/" + stu).then((res) => {
                if (res.code === "0") {
                    this.stuInfoDialog = true;
                    this.$nextTick(() => {
                        this.$refs.form.resetFields();
                        // 生拷贝
                        this.form = JSON.parse(JSON.stringify(res.data));
                    });
                }
            });
        },
        addStuBed() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    // 为床位添加学生
                    this.form.currentCapacity = this.havePeopleNum + 1;
                    request.put("/room/update", this.form).then((res) => {
                        if (res.code === "0") {
                            ElMessage({
                                message: "新增成功",
                                type: "success",
                            });
                            this.search = "";
                            this.loading = true;
                            this.load();
                            this.bedDialog = false;
                        } else {
                            ElMessage({
                                message: res.msg,
                                type: "error",
                            });
                        }
                    });
                }
            });
        },
        editStuBed() {
            //修改
            this.$refs.form.validate((valid) => {
                if (valid) {
                    request.put("/room/update", this.form).then((res) => {
                        if (res.code === "0") {
                            ElMessage({
                                message: "修改成功",
                                type: "success",
                            });
                            this.search = "";
                            this.loading = true;
                            this.load();
                            this.bedDialog = false;
                        } else {
                            ElMessage({
                                message: res.msg,
                                type: "error",
                            });
                        }
                    });
                }
            });
        },
        async deleteStuBed(bedNum, info) {
            let bedName = "";
            // 删除
            if (bedNum === 1) {
                bedName = "first_bed";
            } else if (bedNum === 2) {
                bedName = "second_bed";
            } else if (bedNum === 3) {
                bedName = "third_bed";
            } else if (bedNum === 4) {
                bedName = "fourth_bed";
            }
            //更新当前房间人数
            this.calCurrentNum(info);
            request.delete(
                "/room/delete/" +
                bedName +
                "/" +
                info.dormRoomId +
                "/" +
                this.havePeopleNum
            ).then((res) => {
                if (res.code === "0") {
                    ElMessage({
                        message: "删除成功",
                        type: "success",
                    });
                    this.search = "";
                    this.loading = true;
                    this.load();
                    this.bedDialog = false;
                } else {
                    ElMessage({
                        message: res.msg,
                        type: "error",
                    });
                }
            });
        },
        handleSizeChange(pageSize) {
            //改变每页个数
            this.pageSize = pageSize;
            this.load();
        },
        handleCurrentChange(pageNum) {
            //改变页码
            this.currentPage = pageNum;
            this.load();
        },
    },
};
</script>
<style scoped>
.demo-table-expand {
    font-size: 0;
}

.demo-table-expand label {
    text-align: center;
    width: 90px;
    color: #99a9bf;
}

.demo-table-expand .el-form-item {
    text-align: center;
    margin-right: 0;
    margin-bottom: 0;
    width: 25%;
}

.el-form--inline-icon {
    margin-left: 5px;
    display: flex;
    font-size: 16px;
}

.el-form--inline-icon > .el-icon {
    cursor: pointer;
    margin: 0 5px;
}

.item {
    margin-left: 50px;
    margin-bottom: 0;
    width: 20%;

}
</style>