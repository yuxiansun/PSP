<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="120px">
      <el-form-item label="留言标题" prop="title">
        <el-input
          v-model="queryParams.title"
          placeholder="请输入留言标题"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="留言时间" prop="date">
        <el-date-picker clearable
          v-model="queryParams.date"
          type="date"
          value-format="yyyy-MM-dd"
          placeholder="请选择留言时间">
        </el-date-picker>
      </el-form-item>
      <el-form-item label="留言人名称" prop="accountName">
        <el-input
          v-model="queryParams.accountName"
          placeholder="请输入留言人名称"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="被留言人名称" prop="accountTwoName">
        <el-input
          v-model="queryParams.accountTwoName"
          placeholder="请输入被留言人名称"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="回复内容" prop="replayAccount">
        <el-input
          v-model="queryParams.replayAccount"
          placeholder="请输入回复内容"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="回复时间" prop="replayTime">
        <el-date-picker clearable
          v-model="queryParams.replayTime"
          type="date"
          value-format="yyyy-MM-dd"
          placeholder="请选择回复时间">
        </el-date-picker>
      </el-form-item>
      <el-row style="text-align: center">
        <el-col>
          <el-form-item>
            <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
            <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
          v-hasPermi="['system:message:add']"
        >新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="el-icon-edit"
          size="mini"
          :disabled="single"
          @click="handleUpdate"
          v-hasPermi="['system:message:edit']"
        >修改</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="el-icon-delete"
          size="mini"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['system:message:remove']"
        >删除</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
          v-hasPermi="['system:message:export']"
        >导出</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-tabs v-if="userInfo.roleId != 1" v-model="activeName" @tab-click="handleClickTabs">
      <el-tab-pane label="发出的留言" name="first"></el-tab-pane>
      <el-tab-pane label="收到的留言" name="second"></el-tab-pane>
    </el-tabs>

    <el-table v-loading="loading" :data="messageList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="序号" align="center" prop="index">
        <template slot-scope="scope">
          {{ scope.$index + 1 }}
        </template>
      </el-table-column>
      <el-table-column label="留言标题" align="center" prop="title" />
      <el-table-column label="留言内容" align="center" prop="content" />
      <el-table-column label="留言时间" align="center" prop="date" width="180">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.date, '{y}-{m}-{d}') }}</span>
        </template>
      </el-table-column>
      <el-table-column label="留言账号" align="center" prop="account" />
      <el-table-column label="留言人名称" align="center" prop="accountName" />
      <el-table-column label="被留言人" align="center" prop="accountTwo" />
      <el-table-column label="被留言人名称" align="center" prop="accountTwoName" />
      <el-table-column label="回复内容" align="center" prop="replayAccount" />
      <el-table-column label="回复时间" align="center" prop="replayTime" width="180">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.replayTime, '{y}-{m}-{d}') }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            @click="handleReplay(scope.row)"
            v-if="showButton(scope.row, 'replay')"
          >回复</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['system:message:edit']"
            v-if="showButton(scope.row)"
          >修改</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['system:message:remove']"
            v-if="showButton(scope.row)"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    
    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改【请填写功能名称】对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="80%" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="120px">
        <el-row>
          <el-col :span="12">
            <el-form-item label="留言账号" prop="account">
              <el-input v-model="form.account" disabled placeholder="请输入留言账号" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="留言人姓名" prop="accountName">
              <el-input v-model="form.accountName" disabled placeholder="请输入留言人名称" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="被留言人" prop="accountTwo">
              <el-select v-model="form.accountTwo" @change="changeAccountTwo">
                <el-option v-for="item in fdyAndAdmin" :label="item.userName" :key="item.userId" :value="item.value">
                  {{ item.userName }}<span style="float: right;">{{ item.studentNumber || item.userId }}</span>
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="留言标题" prop="title">
              <el-input v-model="form.title" placeholder="请输入留言标题" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="留言内容">
              <editor v-model="form.content" :min-height="192"/>
            </el-form-item>
          </el-col>
        </el-row>
        <!-- <el-form-item label="留言时间" prop="date">
          <el-date-picker clearable
            v-model="form.date"
            type="date"
            value-format="yyyy-MM-dd"
            placeholder="请选择留言时间">
          </el-date-picker>
        </el-form-item> -->
        <!-- <el-form-item label="被留言人名称" prop="accountTwoName">
          <el-input v-model="form.accountTwoName" placeholder="请输入被留言人名称" />
        </el-form-item> -->
        <!-- <el-form-item label="回复内容" prop="replayAccount">
          <el-input v-model="form.replayAccount" placeholder="请输入回复内容" />
        </el-form-item> -->
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
    <el-dialog :title="title" :visible.sync="replayOpen" width="80%" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="120px">
        <el-row>
          <el-col :span="12">
            <el-form-item label="回复账号" prop="account">
              <el-input v-model="form.account" disabled placeholder="请输入留言账号" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="回复人姓名" prop="accountName">
              <el-input v-model="form.accountName" disabled placeholder="请输入留言人名称" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="回复内容">
              <editor v-model="form.replayAccount" :min-height="192"/>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitFormReplay">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { listMessage, getMessage, delMessage, addMessage, updateMessage } from "@/api/system/message";
import { searchFdyAndAdmin, getUserProfile, listUser } from '@/api/system/user'

export default {
  name: "Message",
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 【请填写功能名称】表格数据
      messageList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      replayOpen: false,
      activeName: 'first',
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        title: null,
        content: null,
        date: null,
        account: null,
        accountTwo: null,
        accountName: null,
        accountTwoName: null,
        replayAccount: null,
        replayTime: null,
      },
      // 表单参数
      form: {
        account: ''
      },
      // 表单校验
      rules: {
      },
      userInfo: {},
      fdyAndAdmin: []
    };
  },
  created() {
    this.getFdyAndAdmin()
  },
  methods: {
    async getFdyAndAdmin() {
      let res = await getUserProfile();
      this.userInfo = res.data;
      if (this.userInfo.roleId != 1) {
        this.queryParams.account = this.userInfo.studentNumber || this.userInfo.userId;
      }
      console.log(this.userInfo, 'userInfo')
      this.getList();
      if (this.userInfo.studentNumber) { 
        // 获取辅导员和宿舍管理员
        searchFdyAndAdmin(this.userInfo.studentNumber).then(res => { 
          this.fdyAndAdmin = res.data.map(item => {
            return {...item, value: item.userId}
          })
        });
      } else {
        // 获取所有人
        listUser({ pageNum: 1, pageSize: null }).then(res => {
          this.fdyAndAdmin = res.rows.map(item => {
            return {...item, value: item.studentNumber || item.userId}
          });
        })
      }
    },
    /** 查询【请填写功能名称】列表 */
    getList() {
      this.loading = true;
      listMessage(this.queryParams).then(response => {
        this.messageList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    changeAccountTwo(value) { 
      let userName = ''
      for (let i = 0; i < this.fdyAndAdmin.length; i++) {
        let item = this.fdyAndAdmin[i]
        if (item.value == value ) {
          this.form.accountTwoName = item.userName;
          break;
        }
      }
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.replayOpen = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        id: null,
        title: null,
        content: null,
        date: null,
        account: null,
        accountTwo: null,
        accountName: null,
        accountTwoName: null,
        replayAccount: null,
        replayTime: null,
        delFlag: null
      };
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.id)
      this.single = selection.length!==1
      this.multiple = !selection.length
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      if (this.userInfo.roleId == 100) {
        this.form.account = this.userInfo.studentNumber;
      } else {
        this.form.account = this.userInfo.userId;
      console.log(this.userInfo, 'userInfo')
      }
      this.form.accountName = this.userInfo.userName;
      this.open = true;
      this.title = "添加【留言信息】";
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset();
      const id = row.id || this.ids
      getMessage(id).then(response => {
        this.form = response.data;
        this.open = true;
        this.title = "修改【留言信息】";
      });
    },
    handleClickTabs(value) { 
      if (this.activeName == 'second') {
        this.queryParams.account = '';
        this.queryParams.accountTwo = this.userInfo.studentNumber || this.userInfo.userId;
      } else {
        this.queryParams.accountTwo = '';
        this.queryParams.account = this.userInfo.studentNumber || this.userInfo.userId;
      }
      this.getList();
    },
    /** 提交按钮 */
    submitForm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          this.form.date = new Date();
          if (this.form.id != null) {
            updateMessage(this.form).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addMessage(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
      });
    },
    /** 修改按钮操作 */
    handleReplay(row) {
      this.reset();
      const id = row.id || this.ids
      getMessage(id).then(response => {
        this.form = response.data;
        this.replayOpen = true;
        this.title = "回复【回复留言】";
      });
    },
    submitFormReplay() { 
      this.form.replayTime = new Date();
      updateMessage(this.form).then(response => {
        this.$modal.msgSuccess("回复成功");
        this.replayOpen = false;
        this.getList();
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const ids = row.id || this.ids;
      this.$modal.confirm('是否确认删除【留言信息】编号为"' + ids + '"的数据项？').then(function() {
        return delMessage(ids);
      }).then(() => {
        this.getList();
        this.$modal.msgSuccess("删除成功");
      }).catch(() => {});
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download('system/message/export', {
        ...this.queryParams
      }, `message_${new Date().getTime()}.xlsx`)
    },
    showButton(row, flag) {
      if (flag) {
        if (this.userInfo.studentNumber) { 
          return row.account != this.userInfo.studentNumber
        } else {
          return row.account != this.userInfo.userId
        }
      }
      if (this.userInfo.studentNumber) { 
        return row.account == this.userInfo.studentNumber
      } else {
        return row.account == this.userInfo.userId
      }
    }
  }
};
</script>
