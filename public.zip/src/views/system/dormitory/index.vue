<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="100px">
      <el-form-item label="宿舍楼号" prop="dormbuildId">
        <el-input v-model="queryParams.dormbuildId" placeholder="请输入宿舍楼号" clearable @keyup.enter.native="handleQuery" />
      </el-form-item>
      <el-form-item label="楼层" prop="floorNum">
        <el-input v-model="queryParams.floorNum" placeholder="请输入楼层" clearable @keyup.enter.native="handleQuery" />
      </el-form-item>
      <el-form-item label="最大入住人数" prop="maxCapacity">
        <el-input v-model="queryParams.maxCapacity" placeholder="请输入最大入住人数" clearable @keyup.enter.native="handleQuery" />
      </el-form-item>
      <el-form-item label="房间入住人数" prop="currentCapacity">
        <el-input v-model="queryParams.currentCapacity" placeholder="请输入当前房间入住人数" clearable
          @keyup.enter.native="handleQuery" />
      </el-form-item>
      <!-- <el-form-item label="一号床位" prop="firstBed">
        <el-input
          v-model="queryParams.firstBed"
          placeholder="请输入一号床位"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item> -->
      <!-- <el-form-item label="二号床位" prop="secondBed">
        <el-input
          v-model="queryParams.secondBed"
          placeholder="请输入二号床位"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="三号床位" prop="thirdBed">
        <el-input
          v-model="queryParams.thirdBed"
          placeholder="请输入三号床位"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="四号床位" prop="fourthBed">
        <el-input
          v-model="queryParams.fourthBed"
          placeholder="请输入四号床位"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item> -->
      <!-- <el-form-item label="五号床位" prop="fivethBed">
        <el-input
          v-model="queryParams.fivethBed"
          placeholder="请输入五号床位"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="六号床位" prop="sixthBed">
        <el-input
          v-model="queryParams.sixthBed"
          placeholder="请输入六号床位"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="七号床位" prop="seventhBed">
        <el-input
          v-model="queryParams.seventhBed"
          placeholder="请输入七号床位"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="八号床位" prop="eightBed">
        <el-input
          v-model="queryParams.eightBed"
          placeholder="请输入八号床位"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item> -->
      <el-row style="text-align:center">
        <el-col :span="24">
          <el-form-item>
            <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
            <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button type="primary" plain icon="el-icon-plus" size="mini" @click="handleAdd"
          v-hasPermi="['system:room:add']">新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button type="success" plain icon="el-icon-edit" size="mini" :disabled="single" @click="handleUpdate"
          v-hasPermi="['system:room:edit']">修改</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button type="danger" plain icon="el-icon-delete" size="mini" :disabled="multiple" @click="handleDelete"
          v-hasPermi="['system:room:remove']">删除</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button type="warning" plain icon="el-icon-download" size="mini" @click="handleExport"
          v-hasPermi="['system:room:export']">导出</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="roomList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="宿舍房间号" align="center" prop="dormroomId" />
      <el-table-column label="宿舍楼号" align="center" prop="dormbuildId" />
      <el-table-column label="楼层" align="center" prop="floorNum" />
      <el-table-column label="房间最大入住人数" align="center" prop="maxCapacity" />
      <el-table-column label="当前房间入住人数" align="center" prop="currentCapacity" />
      <el-table-column type="expand">
        <template slot-scope="props">
          <el-form inline label-position="left" label-width="200px">
            <el-form-item v-for="item in props.row.maxCapacity" class="item" label-width="200px">
              <span slot="label">
                <el-row>
                  <el-col :span="12">
                    <span>{{ handelNumber(item) + '号床位' }}</span>
                    <el-tag v-if="handleKey(props.row, item)" disable-transitions type="primary">
                      {{ handleKey(props.row, item) }}
                    </el-tag>
                  </el-col>
                  <el-col :span="12">
                    <span v-if="handleKey(props.row, item)">
                      <i class="custom-icon el-icon-more" @click="detailIcon(item, props.row)"></i>
                      <i class="custom-icon el-icon-edit-outline" @click="editIcon(item, props.row)"></i>
                    </span>
                    <span v-if="!handleKey(props.row, item)" class="el-form--inline-icon">
                      <i class="custom-icon el-icon-plus" v-if="!handleKey(props.row, item)"
                        @click="plusIcon(item, props.row)"></i>
                      <el-popconfirm title="确认删除？" @confirm="deleteStuBed(item, props.row)">
                        <template slot="reference">
                          <el-icon>
                            <i class="el-icon-delete"></i>
                          </el-icon>
                        </template>
                      </el-popconfirm>
                    </span>
                  </el-col>
                </el-row>
              </span>
            </el-form-item>
          </el-form>
        </template>
      </el-table-column>
      <!-- <el-table-column label="二号床位" align="center" prop="secondBed" />
      <el-table-column label="三号床位" align="center" prop="thirdBed" />
      <el-table-column label="四号床位" align="center" prop="fourthBed" />
      <el-table-column label="五号床位" align="center" prop="fivethBed" />
      <el-table-column label="六号床位" align="center" prop="sixthBed" />
      <el-table-column label="七号床位" align="center" prop="seventhBed" />
      <el-table-column label="八号床位" align="center" prop="eightBed" /> -->
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button size="mini" type="text" icon="el-icon-edit" @click="handleUpdate(scope.row)"
            v-hasPermi="['system:room:edit']">修改</el-button>
          <el-button size="mini" type="text" icon="el-icon-delete" @click="handleDelete(scope.row)"
            v-hasPermi="['system:room:remove']">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination v-show="total > 0" :total="total" :page.sync="queryParams.pageNum" :limit.sync="queryParams.pageSize"
      @pagination="getList" />

    <!-- 添加或修改【宿舍信息】对话框 -->
    <el-dialog key="add" :title="title" :visible.sync="open" width="50%" @close="cancel" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="150px">
        <el-row>
          <el-col :span="12">
            <el-form-item label="宿舍楼号" prop="dormbuildId">
              <el-select v-model="form.dormbuildId" placeholder="请选择的宿舍楼栋">
                <el-option v-for="item in buildList" :key="item.dormbuildId" :label="item.dormbuildName"
                  :value="item.dormbuildId"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="楼层" prop="floorNum">
              <el-input v-model="form.floorNum" placeholder="请输入楼层" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="房间号" prop="dormroomId">
              <el-input v-model="form.dormroomId" placeholder="请输入房间号" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="房间最大入住人数" prop="maxCapacity">
              <el-select v-model="form.maxCapacity" placeholder="请选择房间最大入住人数">
                <el-option v-for="i in 8" :label="i" :value="i" :key="i"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="当前房间入住人数" prop="currentCapacity">
              <el-input v-model="form.currentCapacity" placeholder="请输入当前房间入住人数" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col>
            <el-form-item label="更多">
              <el-switch v-model="showMore">
              </el-switch>
            </el-form-item>
          </el-col>
        </el-row>
        <div v-if="showMore">
          <el-row>
            <el-col :span="12">
              <el-form-item label="一号床位" prop="firstBed">
                <el-select v-model="this.form.firstBed" placeholder="请选择学生">
                  <el-option v-for="item in userList" :key="item.studentNumber" :label="item.userName"
                    :value="item.studentNumber">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="二号床位" prop="secondBed">
                <el-select v-model="this.form.secondBed" placeholder="请选择学生">
                  <el-option v-for="item in userList" :key="item.studentNumber" :label="item.userName"
                    :value="item.studentNumber">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="三号床位" prop="thirdBed">
                <el-select v-model="this.form.thirdBed" placeholder="请选择学生">
                  <el-option v-for="item in userList" :key="item.studentNumber" :label="item.userName"
                    :value="item.studentNumber">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="四号床位" prop="fourthBed">
                <el-select v-model="this.form.fourthBed" placeholder="请选择学生">
                  <el-option v-for="item in userList" :key="item.studentNumber" :label="item.userName"
                    :value="item.studentNumber">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="五号床位" prop="fivethBed">
                <el-select v-model="this.form.fivethBed" placeholder="请选择学生">
                  <el-option v-for="item in userList" :key="item.studentNumber" :label="item.userName"
                    :value="item.studentNumber">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="六号床位" prop="sixthBed">
                <el-select v-model="this.form.sixthBed" placeholder="请选择学生">
                  <el-option v-for="item in userList" :key="item.studentNumber" :label="item.userName"
                    :value="item.studentNumber">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="七号床位" prop="seventhBed">
                <el-select v-model="this.form.seventhBed" placeholder="请选择学生">
                  <el-option v-for="item in userList" :key="item.studentNumber" :label="item.userName"
                    :value="item.studentNumber">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="八号床位" prop="eightBed">
                <el-select v-model="this.form.eightBed" placeholder="请选择学生">
                  <el-option v-for="item in userList" :key="item.studentNumber" :label="item.userName"
                    :value="item.studentNumber">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
        </div>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>

    <el-dialog key="student" :visible.sync="bedDialog" title="操作" width="30%" append-to-body @close="cancel">
      <el-form ref="form" :model="form" :rules="rules" label-width="120px">
        <el-form-item label="楼栋号" prop="dormBuildId">
          <el-select v-model="form.dormbuildId" :disabled="true" placeholder="请选择的宿舍楼栋">
            <el-option v-for="item in buildList" :key="item.dormbuildId" :label="item.dormbuildName"
              :value="item.dormbuildId"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="楼层数" prop="floorNum">
          <el-input v-model.number="form.floorNum" :disabled="true" style="width: 80%"></el-input>
        </el-form-item>
        <el-form-item label="房间号" prop="dormroomId">
          <el-input v-model.number="form.dormroomId" :disabled="true" style="width: 80%"></el-input>
        </el-form-item>
        <el-form-item v-if="this.bedForm.bedNum === 1" label="床位(一)" prop="firstBed">
          <el-select v-model="form.firstBed" placeholder="请选择学生">
            <el-option v-for="item in userList" :key="item.studentNumber" :label="item.userName"
              :value="item.studentNumber">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item v-if="this.bedForm.bedNum === 2" label="床位(二)" prop="secondBed">
          <el-select v-model="form.secondBed" placeholder="请选择学生">
            <el-option v-for="item in userList" :key="item.studentNumber" :label="item.userName"
              :value="item.studentNumber">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item v-if="this.bedForm.bedNum === 3" label="床位(三)" prop="thirdBed">
          <el-select v-model="form.thirdBed" placeholder="请选择学生">
            <el-option v-for="item in userList" :key="item.studentNumber" :label="item.userName"
              :value="item.studentNumber">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item v-if="this.bedForm.bedNum === 4" label="床位(四)" prop="fourthBed">
          <el-select v-model="form.fourthBed" placeholder="请选择学生">
            <el-option v-for="item in userList" :key="item.studentNumber" :label="item.userName"
              :value="item.studentNumber">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item v-if="this.bedForm.bedNum === 5" label="床位(五)" prop="fivethBed">
          <el-select v-model="form.fivethBed" placeholder="请选择学生">
            <el-option v-for="item in userList" :key="item.studentNumber" :label="item.userName"
              :value="item.studentNumber">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item v-if="this.bedForm.bedNum === 6" label="床位(六)" prop="sixthBed">
          <el-select v-model="form.sixthBed" placeholder="请选择学生">
            <el-option v-for="item in userList" :key="item.studentNumber" :label="item.userName"
              :value="item.studentNumber">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item v-if="this.bedForm.bedNum === 7" label="床位(七)" prop="seventhBed">
          <el-select v-model="form.seventhBed" placeholder="请选择学生">
            <el-option v-for="item in userList" :key="item.studentNumber" :label="item.userName"
              :value="item.studentNumber">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item v-if="this.bedForm.bedNum === 8" label="床位(八)" prop="eightBed">
          <el-select v-model="form.eightBed" placeholder="请选择学生">
            <el-option v-for="item in userList" :key="item.studentNumber" :label="item.userName"
              :value="item.studentNumber">
            </el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer">
        <span class="dialog-footer">
          <el-button @click="cancel">取 消</el-button>
          <el-button v-if="this.bedForm.judge === false" type="primary" @click="addStuBed">确 定</el-button>
          <el-button v-if="this.bedForm.judge === true" type="primary" @click="editStuBed">确 定</el-button>
        </span>
      </div>
    </el-dialog>
    <!-- 学生信息弹窗-->
    <el-dialog key="view" :visible.sync="stuInfoDialog" title="学生信息" width="50%" @close="cancel">
      <el-form ref="form" :model="studentForm" label-width="120px">
        <el-form-item label="学号：" prop="studentNumber">
          <el-input v-model="studentForm.studentNumber" disabled />
        </el-form-item>
        <el-form-item label="姓名：" prop="userName">
          <el-input v-model="studentForm.userName" disabled />
        </el-form-item>
        <el-form-item label="性别：" prop="sex">
          <el-input v-model="studentForm.sex" disabled />
        </el-form-item>
        <el-form-item label="手机号：" prop="phonenumber">
          <el-input v-model="studentForm.phonenumber" disabled />
        </el-form-item>
        <el-form-item label="邮箱地址：" prop="email">
          <el-input v-model="studentForm.email" disabled />
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>

<script>
import { listRoom, getRoom, delRoom, addRoom, updateRoom, getUser } from "@/api/system/dormitory";
import { listBuild } from "@/api/system/build";
import { listUser, getUserByNumber, listUserStudent } from "@/api/system/user";

export default {
  name: "Room",
  dicts: ['sys_user_sex'],
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 【宿舍信息】表格数据
      roomList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        dormbuildId: null,
        floorNum: null,
        maxCapacity: null,
        currentCapacity: null,
        firstBed: null,
        secondBed: null,
        thirdBed: null,
        fourthBed: null,
        fivethBed: null,
        sixthBed: null,
        seventhBed: null,
        eightBed: null
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        dormbuildId: [
          { required: true, message: "宿舍楼号不能为空", trigger: "blur" }
        ],
        floorNum: [
          { required: true, message: "楼层不能为空", trigger: "blur" }
        ],
        maxCapacity: [
          { required: true, message: "房间最大入住人数不能为空", trigger: "blur" }
        ],
        currentCapacity: [
          { required: false, message: "当前房间入住人数不能为空", trigger: "blur" }
        ],
      },
      showMore: false,
      buildList: [],
      isAdd: true,
      bedForm: {
        judge: false,
        bedNum: '',

      },
      formTwo: {},
      bedDialog: false,
      // 查询参数
      queryParamsUser: {
        pageNum: 1,
        pageSize: 20000,
        userName: undefined,
        phonenumber: undefined,
        status: undefined,
        deptId: undefined,
        roleId: 100
      },
      userList: [],
      studentForm: {},
      stuInfoDialog: false,
    };
  },
  created() {
    this.getList();
    this.getBuildList();
    this.getUserList();
  },
  methods: {
    getBuildList() {
      listBuild({
        pageNum: 1,
        pageSize: 200,
      }).then(response => {
        this.buildList = response.rows;
      })
    },
    /** 查询【宿舍信息】列表 */
    getList() {
      this.loading = true;
      listRoom(this.queryParams).then(response => {
        this.roomList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    getUserList() {
      listUser(this.addDateRange(this.queryParamsUser, this.dateRange)).then(response => {
        this.userList = response.rows;
      }
      );
    },
    getUserListStudent(sex) {
      if (!sex) {
        sex = '1'
      }
      listUserStudent({ sex, roleId: 100 }).then(res => {
        this.userList = res.data;
      })
    },
    // 取消按钮
    cancel() {
      this.$refs.form.resetFields();
      this.bedDialog = false;
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        dormroomId: null,
        dormbuildId: null,
        floorNum: null,
        maxCapacity: null,
        currentCapacity: null,
        firstBed: null,
        secondBed: null,
        thirdBed: null,
        fourthBed: null,
        fivethBed: null,
        sixthBed: null,
        seventhBed: null,
        eightBed: null
      };
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.dormroomId)
      this.single = selection.length !== 1
      this.multiple = !selection.length
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.isAdd = true;
      this.getBuildList();
      this.reset();
      this.open = true;
      this.title = "添加【宿舍信息】";
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.isAdd = false;
      this.reset();
      const dormroomId = row.dormroomId || this.ids
      getRoom(dormroomId).then(response => {
        this.form = response.data;
        this.open = true;
        this.title = "修改【宿舍信息】";
      });
    },
    plusIcon(index, row) {
      let sex = this.buildList.find(item => item.dormbuildId == row.dormbuildId).dormbuildSex;
      this.getUserListStudent(sex);
      //添加图标
      this.bedForm.judge = false;
      //显示对应床位input
      this.bedForm.bedNum = index;
      //获取当前房间人数
      this.getTotal(row);
      this.bedDialog = true;
      this.$nextTick(() => {
        this.$refs.form.resetFields();
        this.form = JSON.parse(JSON.stringify(row));
      });
    },
    editIcon(num, info) {
      //添加图标
      this.bedForm.judge = true;
      //显示对应床位input
      this.bedForm.bedNum = num;
      //修改床位所住的学生
      this.bedDialog = true;
      this.getTotal(info);
      this.$nextTick(() => {
        this.$refs.form.resetFields();
        // 深拷贝
        this.form = JSON.parse(JSON.stringify(info));
      });
    },
    /** 提交按钮 */
    submitForm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.currentCapacity > this.form.maxCapacity) {
            this.$message.error("当前入住人数不能大于宿舍最大入住人数");
            return;
          }
          this.getTotal(this.form)
          this.form.currentCapacity = this.havePeopleNum;
          if (!this.isAdd) {
            updateRoom(this.form).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.getList();

              this.bedDialog = false;
            });
          } else {
            addRoom(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.getList();
              this.bedDialog = false;
            });
          }
        }
      });
    },

    detailIcon(num, info) {
      //查看床位所住的学生
      let stu = "";
      // 删除
      if (num === 1) {
        stu = info.firstBed;
      } else if (num === 2) {
        stu = info.secondBed;
      } else if (num === 3) {
        stu = info.thirdBed;
      } else if (num === 4) {
        stu = info.fourthBed;
      } else if (num == 5) {
        stu = info.fivethBed;
      } else if (num == 6) {
        stu = info.sixthBed;
      } else if (num == 7) {
        stu = info.seventhBed;
      } else if (num == 8) {
        stu = info.eightBed;
      }
      getUserByNumber(stu).then(res => {
        this.studentForm = res.data;
        this.dict.type.sys_user_sex.forEach(item => {
          if (item.value == this.studentForm.sex) {
            this.studentForm.sex = item.label
          }
        });
        console.log(this.dict)
        this.stuInfoDialog = true;
      })
    },
    addStuBed() {
      this.isAdd = false;
      this.submitForm();
    },
    editStuBed() {
      this.isAdd = false;
      this.submitForm();
    },
    // cancel() {
    //   this.$refs.form.resetFields();
    //   // this.dialogVisible = false;
    //   this.bedDialog = false;
    //   // this.stuInfoDialog = false;
    // },
    /** 删除按钮操作 */
    handleDelete(row) {
      const dormroomIds = row.dormroomId || this.ids;
      this.$modal.confirm('是否确认删除【宿舍信息】编号为"' + dormroomIds + '"的数据项？').then(function () {
        return delRoom(dormroomIds);
      }).then(() => {
        this.getList();
        this.$modal.msgSuccess("删除成功");
      }).catch(() => { });
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download('system/dormitory/export', {
        ...this.queryParams
      }, `dormitory_${new Date().getTime()}.xlsx`)
    },
    handelNumber(number) {
      let arr = ['零', '一', '二', '三', '四', '五', '六', '七', '八'];
      return arr[number]
    },
    handleKey(row, index) {
      let arr = ['zero', 'first', 'second', 'third', 'fourth', 'fiveth', 'sixth', 'seventh', 'eight']
      return row[arr[index] + 'Bed']
    },
    getTotal(info) {
      this.havePeopleNum = 0;
      for (let i = 0; i < info.maxCapacity; i++) {
        if (this.handleKey(info, i + 1)) {
          this.havePeopleNum++;
        }
      }
    },
    deleteStuBed(bedNum, info) {
      let bedName = "";
      // 删除
      if (bedNum === 1) {
        bedName = "first_bed";
      } else if (bedNum === 2) {
        bedName = "second_bed";
      } else if (bedNum === 3) {
        bedName = "third_bed";
      } else if (bedNum === 4) {
        bedName = "fourth_bed";
      }
      //更新当前房间人数
      this.calCurrentNum(info);
      // request.delete(
      //     "/room/delete/" +
      //     bedName +
      //     "/" +
      //     info.dormRoomId +
      //     "/" +
      //     this.havePeopleNum
      // ).then((res) => {
      //     if (res.code === "0") {
      //         ElMessage({
      //             message: "删除成功",
      //             type: "success",
      //         });
      //         this.search = "";
      //         this.loading = true;
      //         this.load();
      //         this.bedDialog = false;
      //     } else {
      //         ElMessage({
      //             message: res.msg,
      //             type: "error",
      //         });
      //     }
      // });
    },
  },
  watch: {
    'form.dormbuildId': {
      handler(newV) {
        if (newV) {
          let sex = this.buildList.find(item => item.dormbuildId == newV).dormbuildSex;
          this.getUserListStudent(sex)
        }
      },
      deep: true
    }
  }
};
</script>

<style scoped>
.demo-table-expand {
  font-size: 0;
}

.demo-table-expand label {
  text-align: center;
  width: 90px;
  color: #99a9bf;
}

.demo-table-expand .el-form-item {
  text-align: center;
  margin-right: 0;
  margin-bottom: 0;
  width: 25%;
}

.el-form--inline-icon {
  margin-left: 5px;
  display: flex;
  font-size: 16px;
}

.el-form--inline-icon>.el-icon {
  cursor: pointer;
  margin: 0 5px;
}

.item {
  margin-left: 0;
  margin-bottom: 0;
  width: 30%;
}

::v-deep.el-form-item__label {
  /* width: 100% !important; */
  width: max-content;
  display: contents;
}

::v-deep .el-form-item__label-wrap {
  width: 100% !important;
}

.custom-icon {
  line-height: inherit;
  color: #409EFF;
  margin-right: 5px;
}
</style>
