<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="120px">
      <el-form-item label="报修人" prop="repairer">
        <el-input
          v-model="queryParams.repairer"
          placeholder="请输入报修人"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="报修宿舍楼" prop="dormbuildId">
        <el-input
          v-model="queryParams.dormbuildId"
          placeholder="请输入报修宿舍楼"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="报修宿舍房间号" prop="dormroomId">
        <el-input
          v-model="queryParams.dormroomId"
          placeholder="请输入报修宿舍房间号"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="标题" prop="title">
        <el-input
          v-model="queryParams.title"
          placeholder="请输入标题"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-row style="text-align: center">
        <el-col>
          <el-form-item>
            <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
            <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
        >新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="el-icon-edit"
          size="mini"
          :disabled="single"
          @click="handleUpdate"
        >修改</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="el-icon-delete"
          size="mini"
          :disabled="multiple"
          @click="handleDelete"
        >删除</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
        >导出</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="repairList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="订单编号" align="center" prop="id" />
      <el-table-column label="报修人" align="center" prop="repairer" />
      <el-table-column label="报修宿舍楼" align="center" prop="dormbuildName" />
      <el-table-column label="报修宿舍房间号" align="center" prop="dormroomId" />
      <el-table-column label="标题" align="center" prop="title" />
      <el-table-column label="标题描述" align="center" prop="content" />
      <el-table-column label="订单状态" align="center" prop="state">
        <template slot-scope="scope">
          <span>{{ scope.row.stateName }}</span>
        </template>
      </el-table-column>
      <el-table-column label="订单创建时间" align="center" prop="orderBuildtime" width="180">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.orderBuildtime, '{y}-{m}-{d}') }}</span>
        </template>
      </el-table-column>
      <el-table-column label="订单完成时间" align="center" prop="orderFinishtime" width="180">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.orderFinishtime, '{y}-{m}-{d}') }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
          >修改</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
          >删除</el-button>
          <el-button
            size="mini"
            type="text"
            @click="handlePass(scope.row)"
            v-hasPermi="['system:repair:status']"
            v-if="scope.row.state == '0'"
          >审核通过</el-button>
          <el-button
            size="mini"
            type="text"
            @click="handleEnd(scope.row)"
            v-hasPermi="['system:repair:status']"
            v-if="scope.row.state == '1'"
          >完成订单</el-button>
        </template>
      </el-table-column>
    </el-table>
    
    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改【请填写功能名称】对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="80%" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="120px">
        <el-row>
          <el-col :span="12">
            <el-form-item label="报修人" prop="repairer">
              <el-input v-model="form.repairer" disabled placeholder="请输入报修人" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="报修人学号" prop="repairer">
              <el-input v-model="form.repairerId" disabled placeholder="请输入报修人学号" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="报修宿舍楼" prop="dormbuildId" disabled>
              <el-select v-model="form.dormbuildId" disabled placeholder="请选择管理的宿舍楼栋">
                <el-option
                  v-for="item in buildList"
                  :key="item.dormbuildId"
                  :label="item.dormbuildName"
                  :value="item.dormbuildId"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="报修宿舍房间号" prop="dormroomId" disabled>
              <el-input v-model="form.dormroomId" disabled placeholder="请输入报修宿舍房间号" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="标题" prop="title">
              <el-input v-model="form.title" placeholder="请输入标题" />
            </el-form-item>
          </el-col>
        </el-row>
        <!-- <el-row>
          <el-col :span="12">
            <el-form-item label="订单完成时间" prop="orderFinishtime">
              <el-date-picker clearable
                v-model="form.orderFinishtime"
                type="date"
                value-format="yyyy-MM-dd"
                placeholder="请选择订单完成时间">
              </el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="订单创建时间" prop="orderBuildtime">
              <el-date-picker clearable
                v-model="form.orderBuildtime"
                type="date"
                value-format="yyyy-MM-dd"
                placeholder="请选择订单创建时间">
              </el-date-picker>
            </el-form-item>
          </el-col>
        </el-row> -->
        <el-row>
          <el-col>
            <el-form-item label="标题描述">
              <el-input v-model="form.content" type="textarea" />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { listRepair, getRepair, delRepair, addRepair, updateRepair, updateRepairStatus } from "@/api/system/repair";
import { getStudentRoom } from "@/api/system/room.js";
import { listBuild } from "@/api/system/build.js";
import { getInfo } from "@/api/login";

const state = {
  '0': '未完成',
  '1': '正在处理',
  '2': '处理完成'
}


export default {
  name: "Repair",
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 【请填写功能名称】表格数据
      repairList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        repairer: null,
        dormbuildId: null,
        dormroomId: null,
        title: null,
        content: null,
        state: null,
        orderBuildtime: null,
        orderFinishtime: null
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        repairer: [
          { required: true, message: "报修人不能为空", trigger: "blur" }
        ],
        dormbuildId: [
          { required: true, message: "报修宿舍楼不能为空", trigger: "blur" }
        ],
        dormroomId: [
          { required: true, message: "报修宿舍房间号不能为空", trigger: "blur" }
        ],
        title: [
          { required: true, message: "表单标题不能为空", trigger: "blur" }
        ],
        content: [
          { required: true, message: "表单内容不能为空", trigger: "blur" }
        ],
        state: [
          { required: true, message: "订单状态不能为空", trigger: "blur" }
        ],
        orderBuildtime: [
          { required: true, message: "订单创建时间不能为空", trigger: "blur" }
        ],
      },
      userInfo: {},
      buildList: []
    };
  },
  created() {
      this.getList();
  },
  methods: {
    /** 查询【请填写功能名称】列表 */
    getList() {
      this.loading = true;
      listRepair(this.queryParams).then(response => {
        this.repairList = response.rows.map(item => {
          if (!item.state) {
            item.state = '0'
          }
          item.stateName = state[item.state + ''];
          return item;
        })
        this.total = response.total;
        this.loading = false;
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        id: null,
        repairer: null,
        dormbuildId: null,
        dormroomId: null,
        title: null,
        content: null,
        state: null,
        orderBuildtime: null,
        orderFinishtime: null
      };
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.id)
      this.single = selection.length!==1
      this.multiple = !selection.length
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.getUserInfo();
      this.getBuild();
      this.reset();
      this.open = true;
      this.title = "添加【报修信息】";
      this.form.repairer = this.userInfo.userName;
      this.form.repairerId = this.userInfo.studentNumber;
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.getUserInfo();
      this.getBuild();
      this.reset();
      const id = row.id || this.ids
      getRepair(id).then(response => {
        this.form = response.data;
        this.open = true;
        this.title = "修改【报修信息】";
      });
    },
    /** 提交按钮 */
    submitForm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.id != null) {
            this.form.orderBuildtime = new Date().getTime();
            updateRepair(this.form).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addRepair(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const ids = row.id || this.ids;
      this.$modal.confirm('是否确认删除【请填写功能名称】编号为"' + ids + '"的数据项？').then(function() {
        return delRepair(ids);
      }).then(() => {
        this.getList();
        this.$modal.msgSuccess("删除成功");
      }).catch(() => {});
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download('system/repair/export', {
        ...this.queryParams
      }, `repair_${new Date().getTime()}.xlsx`)
    },
    getUserInfo() { 
      getInfo().then(response => {
        this.userInfo = response.user;
        this.form.repairer = this.userInfo.userName;
        this.form.repairerId = this.userInfo.studentNumber;
        this.getStudentRoom(this.userInfo.studentNumber);
      });
    },
    getStudentRoom(studentNumber) { 
      if (studentNumber) {
        getStudentRoom(studentNumber).then(res => {
          this.form.dormroomId = res.data.dormroomId;
          this.form.dormbuildId = res.data.dormbuildId;
        })
      }
    },
    getBuild() { 
      listBuild({
        pageNum: 1,
        pageSize: 200
      }).then(res => {
        this.buildList = res.rows;
      })
    },
    handleEnd(row) { 
      this.$modal.confirm('是否完成此项报修订单', res => {
        updateRepairStatus({ state: '2', id: row.id, orderFinishtime: new Date() }).then(res => {
          this.$message.success("处理完成");
          this.getList()
        })
      })
    },
    handlePass(row) {
      this.$modal.confirm('是否受理此项报修').then(res => {
        return updateRepairStatus({ state: '1', id: row.id }).then(res => {
          this.$message.success("处理完成");
          this.getList()
        })
      })
    }
  }
};
</script>
