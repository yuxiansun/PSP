<template>
  <div class="app-container">
    <el-row :gutter="20">
      <el-col :span="6" :xs="24">
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <span>个人信息</span>
          </div>
          <div>
            <div class="text-center">
              <userAvatar :user="user" />
            </div>
            <ul class="list-group list-group-striped">
              <li class="list-group-item">
                <svg-icon icon-class="user" />用户名称
                <div class="pull-right">{{ user.userName }}</div>
              </li>
              <li class="list-group-item" v-if="user.studentNumber">
                用户学号
                <div class="pull-right">{{ user.studentNumber }}</div>
              </li>
              <li class="list-group-item" v-if="user.identifyNumber">
                身份证号
                <div class="pull-right">{{ user.identifyNumber }}</div>
              </li>
              <li class="list-group-item" v-if="user.deptName">
                专业名称
                <div class="pull-right">{{ user.deptName }}</div>
              </li>
              <li class="list-group-item" v-if="user.className">
                所在班级
                <div class="pull-right">{{ user.className }}</div>
              </li>
              <li class="list-group-item">
                住宿信息
                <div class="pull-right">
                  <span @click="showDormitoryInfo" style="color:brown">查看宿舍信息</span>
                </div>
              </li>
              <li class="list-group-item">
                <svg-icon icon-class="phone" />手机号码
                <div class="pull-right">{{ user.phonenumber }}</div>
              </li>
              <li class="list-group-item">
                <svg-icon icon-class="email" />用户邮箱
                <div class="pull-right">{{ user.email }}</div>
              </li>
              <li class="list-group-item">
                <svg-icon icon-class="tree" />所属学院
                <div class="pull-right" v-if="user.dept">{{ user.dept.deptName }}</div>
              </li>
              <li class="list-group-item">
                <svg-icon icon-class="peoples" />所属角色
                <div class="pull-right">{{ roleGroup }}</div>
              </li>
              <li class="list-group-item">
                <svg-icon icon-class="date" />创建日期
                <div class="pull-right">{{ user.createTime }}</div>
              </li>
            </ul>
          </div>
        </el-card>
      </el-col>
      <el-col :span="18" :xs="24">
        <el-card>
          <div slot="header" class="clearfix">
            <span>基本资料</span>
          </div>
          <el-tabs v-model="activeTab">
            <el-tab-pane label="基本资料" name="userinfo">
              <userInfo :user="user" />
            </el-tab-pane>
            <el-tab-pane label="修改密码" name="resetPwd">
              <resetPwd />
            </el-tab-pane>
          </el-tabs>
        </el-card>
      </el-col>
    </el-row>
    <el-dialog :visible.sync="open" append-to-body title="住宿信息">
      <el-form :model="dormitoryForm">
        <el-form-item label="楼栋">
          <span>{{ dormitoryForm.dormbuildName }}</span>
        </el-form-item>
        <el-form-item label="宿舍房间">
          <span>{{ dormitoryForm.dormroomId }}</span>
        </el-form-item>
        <el-form-item label="床位">
          <span>{{ dormitoryForm.bedNumber }}</span>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>

<script>
import userAvatar from "./userAvatar";
import userInfo from "./userInfo";
import resetPwd from "./resetPwd";
import { getUserProfile } from "@/api/system/user";
import { getStudentRoom } from "@/api/system/room";

export default {
  name: "Profile",
  components: { userAvatar, userInfo, resetPwd },
  data() {
    return {
      user: {},
      roleGroup: {},
      postGroup: {},
      activeTab: "userinfo",
      open: false,
      dormitoryForm: {}
    };
  },
  created() {
    this.getUser();
  },
  methods: {
    getUser() {
      getUserProfile().then(response => {
        this.user = response.data;
        this.roleGroup = response.roleGroup;
        this.postGroup = response.postGroup;
      });
    },
    showDormitoryInfo() {
      this.open = true;
      // 查询住宿信息
      getStudentRoom(this.user.studentNumber).then(res => {
        this.dormitoryForm = res.data;
      })
    },
    // showDormitoryInfo() {
    //   this.showDormitoryInfo();
    // }
  }
};
</script>
