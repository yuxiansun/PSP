<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="120px">
      <el-form-item label="学号" prop="studentNumber">
        <el-input v-model="queryParams.studentNumber" placeholder="请输入学号" clearable @keyup.enter.native="handleQuery" />
      </el-form-item>
      <el-form-item label="学生姓名" prop="studentName">
        <el-input v-model="queryParams.studentName" placeholder="请输入学生姓名" clearable @keyup.enter.native="handleQuery" />
      </el-form-item>
      <el-form-item label="楼栋" prop="dormbuildId">
        <el-input v-model="queryParams.dormbuildId" placeholder="请输入楼栋" clearable @keyup.enter.native="handleQuery" />
      </el-form-item>
      <el-form-item label="宿舍房间号" prop="dormroomId">
        <el-input v-model="queryParams.dormroomId" placeholder="请输入宿舍房间号" clearable @keyup.enter.native="handleQuery" />
      </el-form-item>
      <el-form-item label="专业" prop="deptName">
        <el-input v-model="queryParams.deptName" placeholder="请输入专业" clearable @keyup.enter.native="handleQuery" />
      </el-form-item>
      <el-form-item label="班级" prop="classN">
        <el-input v-model="queryParams.classN" placeholder="请输入班级" clearable @keyup.enter.native="handleQuery" />
      </el-form-item>
      <el-form-item label="到校时间" prop="enterTimeEnd">
        <el-date-picker clearable v-model="queryParams.enterTimeEnd" type="date" value-format="yyyy-MM-dd"
          placeholder="请选择到校时间">
        </el-date-picker>
      </el-form-item>
      <el-form-item label="交通工具" prop="vehicle">
        <el-input v-model="queryParams.vehicle" placeholder="请输入交通工具" clearable @keyup.enter.native="handleQuery" />
      </el-form-item>
      <el-row style="text-align: center">
        <el-col>
          <el-form-item>
            <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
            <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button type="primary" plain icon="el-icon-plus" size="mini" @click="handleAdd"
          v-hasPermi="['system:enter:add']">新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button type="success" plain icon="el-icon-edit" size="mini" :disabled="single" @click="handleUpdate"
          v-hasPermi="['system:enter:edit']">修改</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button type="danger" plain icon="el-icon-delete" size="mini" :disabled="multiple" @click="handleDelete"
          v-hasPermi="['system:enter:remove']">删除</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button type="warning" plain icon="el-icon-download" size="mini" @click="handleExport"
          v-hasPermi="['system:enter:export']">导出</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="enterList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="序号" align="center" prop="index">
        <template slot-scope="scope">
          {{ scope.$index + 1 }}
        </template>
      </el-table-column>
      <el-table-column width="150" label="学号" align="center" prop="studentNumber" />
      <el-table-column label="学生姓名" align="center" prop="studentName" />
      <el-table-column width="200" label="身份证号" align="center" prop="identifyNumber" />
      <el-table-column label="性别" align="center" prop="studentSex" />
      <el-table-column label="楼栋" align="center" prop="dormbuildId" />
      <el-table-column label="宿舍房间号" align="center" prop="dormroomId" />
      <el-table-column label="返校时间" align="center" prop="enterTime" width="180">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.enterTime, '{y}-{m}-{d}') }}</span>
        </template>
      </el-table-column>
      <el-table-column label="返校前住址" align="center" prop="enterAddress" />
      <el-table-column width="120" label="学生电话" align="center" prop="studentPhone" />
      <el-table-column label="目的地" align="center" prop="destination" />
      <el-table-column label="专业" align="center" prop="deptName" />
      <el-table-column label="班级" align="center" prop="classN" />
      <el-table-column label="出发地" align="center" prop="placeOfDeparture" />
      <el-table-column label="到校时间" align="center" prop="enterTimeEnd" width="180">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.enterTimeEnd, '{y}-{m}-{d}') }}</span>
        </template>
      </el-table-column>
      <el-table-column label="中转地" align="center" prop="transfer" />
      <el-table-column label="交通工具" align="center" prop="vehicle" />
      <el-table-column label="健康状况" align="center" prop="health" />
      <el-table-column label="审核状态" align="center" prop="state">
        <template slot-scope="scope">
          <span v-if="!scope.row.state">待审核</span>
          <span v-else>
            {{ scope.row.state == 1 ? '审核通过' : '审核不通过' }}
          </span>
        </template>
      </el-table-column>
      <el-table-column label="审核意见" align="center" prop="fdyHandleOptions" />
      <el-table-column width="200" label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            v-if="(userInfo.roleId == 100 && scope.row.studentNumber == userInfo.studentNumber) || userInfo.roleId != 100"
            size="mini" type="text" icon="el-icon-edit" @click="handleUpdate(scope.row)"
            v-hasPermi="['system:enter:edit']">修改</el-button>
          <el-button
            v-if="(userInfo.roleId == 100 && scope.row.studentNumber == userInfo.studentNumber) || userInfo.roleId != 100"
            size="mini" type="text" icon="el-icon-delete" @click="handleDelete(scope.row)"
            v-hasPermi="['system:enter:remove']">删除</el-button>
          <el-button size="mini" type="text" icon="el-icon-edit" @click="handleCheck(scope.row)"
            v-hasPermi="['system:enter:check']">审核</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination v-show="total > 0" :total="total" :page.sync="queryParams.pageNum" :limit.sync="queryParams.pageSize"
      @pagination="getList" />

    <!-- 添加或修改【请填写功能名称】对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="80%" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="120px">
        <el-row>
          <el-col :span="12">
            <el-form-item label="学号" prop="studentNumber">
              <el-input disabled v-model="form.studentNumber" placeholder="请输入学号" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="学生姓名" prop="studentName">
              <el-input disabled v-model="form.studentName" placeholder="请输入学生姓名" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="专业" prop="deptName">
              <treeselect disabled v-model="form.deptName" :options="deptOptions" :show-count="true"
                placeholder="请选择归属学院" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="班级" prop="classN">
              <el-input disabled v-model="form.classN" placeholder="请输入班级" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="身份证号" prop="identifyNumber">
              <el-input v-model="form.identifyNumber" placeholder="请输入身份证号" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="学生电话" prop="studentPhone">
              <el-input v-model="form.studentPhone" placeholder="请输入学生电话" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="楼栋" prop="dormbuildId">
              <el-select v-model="form.dormbuildId" disabled placeholder="请选择的宿舍楼栋">
                <el-option v-for="item in buildList" :key="item.dormbuildId" :label="item.dormbuildName"
                  :value="item.dormbuildId"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="宿舍房间号" prop="dormroomId">
              <el-input disabled v-model="form.dormroomId" placeholder="请输入宿舍房间号" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="返校前住址" prop="enterAddress">
              <el-input v-model="form.enterAddress" placeholder="请输入返校前住址" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="返校时间" prop="enterTime">
              <el-date-picker clearable v-model="form.enterTime" type="date" value-format="yyyy-MM-dd"
                placeholder="请选择返校时间">
              </el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="出发地" prop="placeOfDeparture">
              <el-input v-model="form.placeOfDeparture" placeholder="请输入出发地" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="目的地" prop="destination">
              <el-input v-model="form.destination" placeholder="请输入目的地" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="中转地" prop="transfer">
              <el-input v-model="form.transfer" placeholder="请输入中转地" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="交通工具" prop="vehicle">
              <el-input v-model="form.vehicle" placeholder="请输入交通工具" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="到校时间" prop="enterTimeEnd">
              <el-date-picker clearable v-model="form.enterTimeEnd" type="date" value-format="yyyy-MM-dd"
                placeholder="请选择到校时间">
              </el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="健康状况" prop="health">
              <el-input v-model="form.health" placeholder="请输入健康状况" />
            </el-form-item>
          </el-col>
        </el-row>

      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
    <el-dialog title="审核" :visible.sync="open2" width="80%" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="120px">
        <el-row>
          <el-col :span="12">
            <el-form-item label="学号" prop="studentNumber">
              <el-input disabled v-model="form.studentNumber" placeholder="请输入学号" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="学生姓名" prop="studentName">
              <el-input disabled v-model="form.studentName" placeholder="请输入学生姓名" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="专业" prop="deptName">
              <treeselect disabled v-model="form.deptName" :options="deptOptions" :show-count="true"
                placeholder="请选择归属学院" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="班级" prop="classN">
              <el-input disabled v-model="form.classN" placeholder="请输入班级" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="身份证号" prop="identifyNumber">
              <el-input disabled v-model="form.identifyNumber" placeholder="请输入身份证号" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="学生电话" prop="studentPhone">
              <el-input disabled v-model="form.studentPhone" placeholder="请输入学生电话" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="楼栋" prop="dormbuildId">
              <el-select disabled v-model="form.dormbuildId" disabled placeholder="请选择的宿舍楼栋">
                <el-option v-for="item in buildList" :key="item.dormbuildId" :label="item.dormbuildName"
                  :value="item.dormbuildId"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="宿舍房间号" prop="dormroomId">
              <el-input disabled v-model="form.dormroomId" placeholder="请输入宿舍房间号" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="返校前住址" prop="enterAddress">
              <el-input disabled v-model="form.enterAddress" placeholder="请输入返校前住址" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="返校时间" prop="enterTime">
              <el-date-picker disabled clearable v-model="form.enterTime" type="date" value-format="yyyy-MM-dd"
                placeholder="请选择返校时间">
              </el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="出发地" prop="placeOfDeparture">
              <el-input disabled v-model="form.placeOfDeparture" placeholder="请输入出发地" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="目的地" prop="destination">
              <el-input disabled v-model="form.destination" placeholder="请输入目的地" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="中转地" prop="transfer">
              <el-input disabled v-model="form.transfer" placeholder="请输入中转地" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="交通工具" prop="vehicle">
              <el-input disabled v-model="form.vehicle" placeholder="请输入交通工具" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="到校时间" prop="enterTimeEnd">
              <el-date-picker disabled clearable v-model="form.enterTimeEnd" type="date" value-format="yyyy-MM-dd"
                placeholder="请选择到校时间">
              </el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item disabled label="健康状况" prop="health">
              <el-input disabled v-model="form.health" placeholder="请输入健康状况" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="审核状态" prop="state">
              <el-select v-model="form.state" placeholder="请选择的宿舍楼栋">
                <el-option v-for="item in stateList" :key="item.id" :label="item.label" :value="item.id"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col v-if="userInfo.roleId == 102" :span="12">
            <el-form-item label="辅导员审核意见" :required="form.state == 2" prop="fdyHandleOptions">
              <el-input v-model="form.fdyHandleOptions" placeholder="请输入辅导员审核意见" />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" classN="dialog-footer">
        <el-button type="primary" @click="submitCheckForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { deptTreeSelect } from "@/api/system/user";
import { listEnter, getEnter, delEnter, addEnter, updateEnter } from "@/api/system/enter";
import { getStudentRoom } from '@/api/system/room'
import { listBuild } from '@/api/system/build'
import Treeselect from "@riophae/vue-treeselect";
import "@riophae/vue-treeselect/dist/vue-treeselect.css";
const stateList = [
  {
    id: 1,
    label: '审核通过'
  },
  {
    id: 2,
    label: '审核不通过'
  }
]

export default {
  name: "Enter",
  components: {
    treeselect: Treeselect
  },
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 【请填写功能名称】表格数据
      enterList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        studentNumber: null,
        studentName: null,
        studentSex: null,
        dormbuildId: null,
        dormroomId: null,
        enterTime: null,
        enterAddress: null,
        studentPhone: null,
        destination: null,
        deptName: null,
        classN: null,
        placeOfDeparture: null,
        enterTimeEnd: null,
        transfer: null,
        vehicle: null,
        health: null,
        state: null,
        identifyNumber: null
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
      },
      dormInfo: {},
      userInfo: {},
      buildList: [],
      deptOptions: undefined,
      open2: false,
      stateList
    };
  },
  created() {
    this.getUser()
    this.getList();
    this.getListBuild();
    this.getDeptTree();
  },
  methods: {
    /** 查询学院下拉树结构 */
    getDeptTree() {
      deptTreeSelect().then(response => {
        this.deptOptions = response.data;
      });
    },
    /** 查询【请填写功能名称】列表 */
    getList() {
      if (this.userInfo.roleId == 102) {
        this.queryParams.studentCounsellorId = this.userInfo.userId;
      }
      this.loading = true;
      listEnter(this.queryParams).then(response => {
        this.enterList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    getListBuild() {
      listBuild({ pageNum: 1, pageSize: 100 }).then(res => {
        this.buildList = res.rows;
      })
    },
    getUser() {
      let user = JSON.parse(sessionStorage.getItem('userInfo'));
      this.userInfo = user;
      console.log(user, 'user')
      if (user.studentNumber) {
        getStudentRoom(user.studentNumber).then(res => {
          this.dormInfo = res.data;
        })
      }
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        id: null,
        studentNumber: null,
        studentName: null,
        studentSex: null,
        dormbuildId: null,
        dormroomId: null,
        enterTime: null,
        enterAddress: null,
        studentPhone: null,
        destination: null,
        deptName: null,
        classN: null,
        placeOfDeparture: null,
        enterTimeEnd: null,
        transfer: null,
        vehicle: null,
        health: null,
        state: null,
        delFlag: null,
        identifyNumber: null
      };
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    setFormInfo() {
      this.form.studentNumber = this.userInfo.studentNumber;
      this.form.studentName = this.userInfo.userName;
      this.form.dormbuildId = this.dormInfo.dormbuildId * 1
      this.form.dormroomId = this.dormInfo.dormroomId
      this.form.bedNumber = this.dormInfo.bedNumber
      this.form.studentSex = this.userInfo.sex;
      this.form.identifyNumber = this.userInfo.identifyNumber;
      this.form.deptName = this.userInfo.deptName;
      this.form.classN = this.userInfo.manageClass;
      this.form.deptName = this.userInfo.deptId;
      this.form.studentCounsellorId = this.userInfo.studentCounsellorId;
      this.form.studentCounsellorName = this.userInfo.studentCounsellorName
      this.form.studentPhone = this.userInfo.phonenumber;
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.id)
      this.single = selection.length !== 1
      this.multiple = !selection.length
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      this.setFormInfo();
      this.open = true;
      this.title = "添加【学生返校信息】";
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset();
      const id = row.id || this.ids
      getEnter(id).then(response => {
        this.form = response.data;
        this.open = true;
        this.title = "修改【学生返校信息】";
      });
    },
    /** 提交按钮 */
    submitForm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.id != null) {
            updateEnter(this.form).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addEnter(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const ids = row.id || this.ids;
      this.$modal.confirm('是否确认删除【学生返校信息】编号为"' + ids + '"的数据项？').then(function () {
        return delEnter(ids);
      }).then(() => {
        this.getList();
        this.$modal.msgSuccess("删除成功");
      }).catch(() => { });
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download('system/enter/export', {
        ...this.queryParams
      }, `enter_${new Date().getTime()}.xlsx`)
    },

    handleCheck(row) {
      this.reset();
      const id = row.id || this.ids
      getEnter(id).then(response => {
        response.data.state = response.data.state * 1
        if (response.data.state == 0) {
          response.data.state = 1
        }
        this.form = response.data;
        this.open2 = true;
      });
    },
    submitCheckForm() {
      if (this.userInfo.roleId == 101) {
        this.form.dormHandleTime = new Date();
      } else {
        this.form.fdyHandleTime = new Date()
      }
      updateEnter(this.form).then(response => {
        this.$modal.msgSuccess("处理成功");
        this.open2 = false;
        this.getList();
      });
    }
  }
};
</script>
