<template>
  <div>学生宿舍</div>
</template>